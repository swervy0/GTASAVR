/* GTASA_VR - thin C bridge over the OpenVR flat C API (FnTables).
   openvr_capi.h only compiles as C, so everything OpenVR lives here. */
#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "openvr_capi.h"
#include "vrapi.h"

typedef uint32_t (__cdecl *PFN_InitInternal2)(EVRInitError *, EVRApplicationType, const char *);
typedef void     (__cdecl *PFN_ShutdownInternal)(void);
typedef void *   (__cdecl *PFN_GetGenericInterface)(const char *, EVRInitError *);
typedef bool     (__cdecl *PFN_IsHmdPresent)(void);
typedef const char *(__cdecl *PFN_GetEnumAsSymbol)(EVRInitError);

static HMODULE g_dll;
static PFN_ShutdownInternal pShutdown;
static struct VR_IVRSystem_FnTable     *g_sys;
static struct VR_IVRCompositor_FnTable *g_comp;
static struct VR_IVROverlay_FnTable    *g_ovl;
static VROverlayHandle_t g_overlay;

static void *get_iface(PFN_GetGenericInterface gi, const char *ver, char *err, int errlen)
{
    char name[128];
    EVRInitError e = EVRInitError_VRInitError_None;
    void *p;
    snprintf(name, sizeof(name), "FnTable:%s", ver);
    p = gi(name, &e);
    if (!p || e != EVRInitError_VRInitError_None) {
        snprintf(err, errlen, "VR_GetGenericInterface(%s) failed, error %d", name, (int)e);
        return NULL;
    }
    return p;
}

int vr_init(const char *dll_path, char *err, int errlen)
{
    PFN_InitInternal2 pInit;
    PFN_GetGenericInterface pGet;
    PFN_IsHmdPresent pPresent;
    EVRInitError e = EVRInitError_VRInitError_None;

    g_dll = LoadLibraryA(dll_path);
    if (!g_dll) {
        snprintf(err, errlen, "Could not load %s (Windows error %lu). Put openvr_api.dll next to gta_sa.exe.", dll_path, GetLastError());
        return 0;
    }
    pInit     = (PFN_InitInternal2)GetProcAddress(g_dll, "VR_InitInternal2");
    pShutdown = (PFN_ShutdownInternal)GetProcAddress(g_dll, "VR_ShutdownInternal");
    pGet      = (PFN_GetGenericInterface)GetProcAddress(g_dll, "VR_GetGenericInterface");
    pPresent  = (PFN_IsHmdPresent)GetProcAddress(g_dll, "VR_IsHmdPresent");
    if (!pInit || !pShutdown || !pGet) {
        snprintf(err, errlen, "openvr_api.dll is missing exports (wrong/32-bit vs 64-bit DLL?)");
        return 0;
    }
    if (pPresent && !pPresent()) {
        snprintf(err, errlen, "No headset detected by SteamVR");
        return 0;
    }
    pInit(&e, EVRApplicationType_VRApplication_Scene, NULL);
    if (e != EVRInitError_VRInitError_None) {
        snprintf(err, errlen, "VR_InitInternal2 failed, error %d (is SteamVR running?)", (int)e);
        return 0;
    }
    g_sys  = get_iface(pGet, IVRSystem_Version, err, errlen);     if (!g_sys)  return 0;
    g_comp = get_iface(pGet, IVRCompositor_Version, err, errlen); if (!g_comp) return 0;
    g_ovl  = get_iface(pGet, IVROverlay_Version, err, errlen);    /* optional */
    g_comp->SetTrackingSpace(ETrackingUniverseOrigin_TrackingUniverseStanding);
    return 1;
}

void vr_shutdown(void)
{
    if (pShutdown) pShutdown();
    g_sys = NULL; g_comp = NULL; g_ovl = NULL;
}

int vr_adapter_index(void)
{
    int32_t idx = -1;
    if (g_sys) g_sys->GetDXGIOutputInfo(&idx);
    return idx;
}

void vr_recommended_size(uint32_t *w, uint32_t *h)
{
    *w = *h = 0;
    if (g_sys) g_sys->GetRecommendedRenderTargetSize(w, h);
}

void vr_projection_raw(int eye, float *l, float *r, float *t, float *b)
{
    g_sys->GetProjectionRaw(eye ? EVREye_Eye_Right : EVREye_Eye_Left, l, r, t, b);
}

void vr_eye_to_head(int eye, float out[12])
{
    struct HmdMatrix34_t m = g_sys->GetEyeToHeadTransform(eye ? EVREye_Eye_Right : EVREye_Eye_Left);
    memcpy(out, m.m, sizeof(float) * 12);
}

int vr_wait_poses(float hmd[12], float ctrl[2][12], int ctrl_valid[2])
{
    TrackedDevicePose_t poses[k_unMaxTrackedDeviceCount];
    TrackedDeviceIndex_t idx;
    int ok = 0, hand;
    if (!g_comp) return 0;
    if (g_comp->WaitGetPoses(poses, k_unMaxTrackedDeviceCount, NULL, 0) != EVRCompositorError_VRCompositorError_None)
        return 0;
    if (poses[k_unTrackedDeviceIndex_Hmd].bPoseIsValid) {
        memcpy(hmd, poses[k_unTrackedDeviceIndex_Hmd].mDeviceToAbsoluteTracking.m, sizeof(float) * 12);
        ok = 1;
    }
    if (!ctrl || !ctrl_valid) return ok;
    for (hand = 0; hand < 2; hand++) {
        ctrl_valid[hand] = 0;
        idx = g_sys->GetTrackedDeviceIndexForControllerRole(hand ? ETrackedControllerRole_TrackedControllerRole_RightHand
                                                                 : ETrackedControllerRole_TrackedControllerRole_LeftHand);
        if (idx < k_unMaxTrackedDeviceCount && poses[idx].bPoseIsValid) {
            memcpy(ctrl[hand], poses[idx].mDeviceToAbsoluteTracking.m, sizeof(float) * 12);
            ctrl_valid[hand] = 1;
        }
    }
    return ok;
}

int vr_submit(int eye, void *d3d11_tex, float umin, float vmin, float umax, float vmax, const float pose[12])
{
    VRTextureWithPose_t tex;
    VRTextureBounds_t bounds;
    EVRCompositorError e;
    memset(&tex, 0, sizeof(tex));
    tex.handle = d3d11_tex;
    tex.eType = ETextureType_TextureType_DirectX;
    tex.eColorSpace = EColorSpace_ColorSpace_Auto;
    memcpy(tex.mDeviceToAbsoluteTracking.m, pose, sizeof(float) * 12);
    bounds.uMin = umin; bounds.vMin = vmin; bounds.uMax = umax; bounds.vMax = vmax;
    e = g_comp->Submit(eye ? EVREye_Eye_Right : EVREye_Eye_Left, (struct Texture_t *)&tex, &bounds,
                       EVRSubmitFlags_Submit_TextureWithPose);
    return (int)e;
}

/* ---- virtual screen overlay (menus / map / flat view) ---- */

int vr_overlay_create(void)
{
    if (!g_ovl) return 0;
    if (g_overlay) return 1;
    if (g_ovl->CreateOverlay("gtasa_vr.screen", "GTA San Andreas", &g_overlay) != EVROverlayError_VROverlayError_None) {
        g_overlay = 0;
        return 0;
    }
    g_ovl->SetOverlayWidthInMeters(g_overlay, 3.2f);
    return 1;
}

void vr_overlay_place(const float hmd[12], float distance)
{
    /* Put the screen `distance` metres in front of the headset, upright, facing it (yaw only). */
    struct HmdMatrix34_t m;
    float fx, fz, len;
    if (!g_overlay) return;
    fx = -hmd[2]; fz = -hmd[10];               /* -Z column = forward */
    len = sqrtf(fx * fx + fz * fz);
    if (len < 1e-3f) { fx = 0; fz = -1; len = 1; }
    fx /= len; fz /= len;
    memset(&m, 0, sizeof(m));
    /* overlay +Z must face the viewer => overlay Z = -forward */
    m.m[0][0] = -fz; m.m[0][1] = 0; m.m[0][2] = -fx;
    m.m[1][0] = 0;   m.m[1][1] = 1; m.m[1][2] = 0;
    m.m[2][0] = fx;  m.m[2][1] = 0; m.m[2][2] = -fz;
    m.m[0][3] = hmd[3] + fx * distance;
    m.m[1][3] = hmd[7];
    m.m[2][3] = hmd[11] + fz * distance;
    g_ovl->SetOverlayTransformAbsolute(g_overlay, ETrackingUniverseOrigin_TrackingUniverseStanding, &m);
}

void vr_overlay_show(void *d3d11_tex, int show)
{
    struct Texture_t t;
    if (!g_overlay) return;
    if (show) {
        t.handle = d3d11_tex;
        t.eType = ETextureType_TextureType_DirectX;
        t.eColorSpace = EColorSpace_ColorSpace_Auto;
        g_ovl->SetOverlayTexture(g_overlay, &t);
        g_ovl->ShowOverlay(g_overlay);
    } else {
        g_ovl->HideOverlay(g_overlay);
    }
}

/* ---- controllers (legacy input API: works with every controller via SteamVR legacy bindings) ---- */

int vr_controller_state(int hand, uint64_t *pressed, uint64_t *touched, float axes[10])
{
    VRControllerState_t st;
    TrackedDeviceIndex_t idx;
    int i;
    *pressed = *touched = 0;
    memset(axes, 0, sizeof(float) * 10);
    if (!g_sys) return 0;
    idx = g_sys->GetTrackedDeviceIndexForControllerRole(hand ? ETrackedControllerRole_TrackedControllerRole_RightHand
                                                             : ETrackedControllerRole_TrackedControllerRole_LeftHand);
    if (idx >= k_unMaxTrackedDeviceCount) return 0;
    memset(&st, 0, sizeof(st));
    if (!g_sys->GetControllerState(idx, &st, sizeof(st))) return 0;
    *pressed = st.ulButtonPressed;
    *touched = st.ulButtonTouched;
    for (i = 0; i < 5; i++) { axes[i * 2] = st.rAxis[i].x; axes[i * 2 + 1] = st.rAxis[i].y; }
    return 1;
}

void vr_haptic(int hand, unsigned short micros)
{
    TrackedDeviceIndex_t idx;
    if (!g_sys) return;
    idx = g_sys->GetTrackedDeviceIndexForControllerRole(hand ? ETrackedControllerRole_TrackedControllerRole_RightHand
                                                             : ETrackedControllerRole_TrackedControllerRole_LeftHand);
    if (idx < k_unMaxTrackedDeviceCount) g_sys->TriggerHapticPulse(idx, 0, micros);
}

/* Ray from a controller pose (-Z forward) against the virtual screen. u,v in 0..1, v=0 at the TOP. */
int vr_overlay_intersect(const float ctrl[12], float *u, float *v)
{
    VROverlayIntersectionParams_t p;
    VROverlayIntersectionResults_t r;
    if (!g_ovl || !g_overlay) return 0;
    p.vSource.v[0] = ctrl[3]; p.vSource.v[1] = ctrl[7]; p.vSource.v[2] = ctrl[11];
    p.vDirection.v[0] = -ctrl[2]; p.vDirection.v[1] = -ctrl[6]; p.vDirection.v[2] = -ctrl[10];
    p.eOrigin = ETrackingUniverseOrigin_TrackingUniverseStanding;
    if (!g_ovl->ComputeOverlayIntersection(g_overlay, &p, &r)) return 0;
    *u = r.vUVs.v[0];
    *v = 1.0f - r.vUVs.v[1];   /* overlay UVs are bottom-up */
    return 1;
}

/* ---- HUD panel overlay (head-locked, premultiplied alpha) ---- */
static VROverlayHandle_t g_hud;

int vr_hud_create(float width)
{
    if (!g_ovl) return 0;
    if (g_hud) return 1;
    if (g_ovl->CreateOverlay("gtasa_vr.hud", "GTA SA HUD", &g_hud) != EVROverlayError_VROverlayError_None) { g_hud = 0; return 0; }
    g_ovl->SetOverlayWidthInMeters(g_hud, width);
    g_ovl->SetOverlayFlag(g_hud, VROverlayFlags_IsPremultiplied, 1);
    g_ovl->SetOverlaySortOrder(g_hud, 1);
    return 1;
}

void vr_hud_place(float distance, float down)
{
    struct HmdMatrix34_t m;
    if (!g_hud) return;
    memset(&m, 0, sizeof(m));
    m.m[0][0] = 1; m.m[1][1] = 1; m.m[2][2] = 1;
    m.m[1][3] = -down; m.m[2][3] = -distance;
    g_ovl->SetOverlayTransformTrackedDeviceRelative(g_hud, k_unTrackedDeviceIndex_Hmd, &m);
}

void vr_hud_show(void *d3d11_tex, int show)
{
    struct Texture_t t;
    if (!g_hud) return;
    if (show) {
        t.handle = d3d11_tex; t.eType = ETextureType_TextureType_DirectX; t.eColorSpace = EColorSpace_ColorSpace_Auto;
        g_ovl->SetOverlayTexture(g_hud, &t);
        g_ovl->ShowOverlay(g_hud);
    } else {
        g_ovl->HideOverlay(g_hud);
    }
}
