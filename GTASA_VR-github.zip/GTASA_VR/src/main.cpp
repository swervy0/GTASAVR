// GTASA_VR — VR mod for GTA San Andreas 1.0 US (stage 1: SteamVR output + 6DOF head tracking)
//
// How it works
//  * Alternate-eye rendering: the game renders ONE eye per frame (left, right, left, ...). Before
//    the game renders, we move its camera to that eye's position/orientation (from the headset),
//    and widen its view so it covers the headset's lens field of view. At Present we copy the
//    finished frame to SteamVR for that eye. Each eye is submitted with the head pose it was
//    rendered with, so SteamVR reprojects the older eye correctly.
//  * The headset rotates/translates the view on top of the game's camera yaw ("decoupled" look):
//    mouse/stick still turns CJ, your head looks around freely.
//  * Menus, loading screens, map: shown on a floating virtual screen.
//
// Addresses are for gta_sa.exe 1.0 US (checked against the user's exe).

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <d3d9.h>
#include <d3d11.h>
#include <dxgi.h>
#include <cmath>
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <cstdarg>
#include <utility>
#include "vrapi.h"

// ------------------------------------------------------------------------------------------
// Game addresses (1.0 US)
// ------------------------------------------------------------------------------------------
namespace game {
    constexpr uintptr_t TheCamera            = 0xB6F028;
    constexpr uintptr_t Cam_WideScreenOn     = TheCamera + 0x3D;   // bool, cutscene bars
    constexpr uintptr_t Cam_Matrix           = TheCamera + 0x974;  // CMatrix m_mCameraMatrix
    constexpr uintptr_t Scene_RwCamera       = 0xC1703C;           // RwCamera*
    constexpr uintptr_t D3DDevicePtr         = 0xC97C28;           // IDirect3DDevice9*
    constexpr uintptr_t GameState            = 0xC8D4C0;           // 9 = in game loop
    constexpr uintptr_t MenuActive           = 0xBA6748 + 0x5C;    // FrontEndMenuManager.m_bMenuActive
    constexpr uintptr_t Draw_FOV             = 0x8D5038;           // CDraw::ms_fFOV (degrees, horizontal)
    constexpr uintptr_t Draw_Aspect          = 0xC3EFA4;           // CDraw::ms_fAspectRatio

    constexpr uintptr_t fn_CalcDerived       = 0x5150E0;           // CCamera::CalculateDerivedValues(bool,bool)
    constexpr uintptr_t fn_CameraSize        = 0x72FC70;           // CameraSize(RwCamera*,RwRect*,float,float)
    constexpr uintptr_t fn_RwCamSetViewWin   = 0x7EE410;           // RwCameraSetViewWindow
    constexpr uintptr_t fn_RwCamSetNearClip  = 0x7EE1D0;           // RwCameraSetNearClipPlane
    constexpr uintptr_t fn_FindPlayerPed     = 0x56E210;           // CPed* FindPlayerPed(int)
    constexpr uintptr_t fn_GetBonePosition   = 0x5E4280;           // CPed::GetBonePosition(CVector*,int,bool)

    // Call sites we redirect
    constexpr uintptr_t site_ProcessCalcDerived = 0x52C983;        // inside CCamera::Process, right after SetFOV
    constexpr uintptr_t site_CameraSize_A       = 0x53D708;        // DoRWStuffStartOfFrame
    constexpr uintptr_t site_CameraSize_B       = 0x53D7D3;        // DoRWStuffStartOfFrame_Horizon (in-game)
}

template <class T> static T& Mem(uintptr_t a) { return *reinterpret_cast<T*>(a); }

struct V3 { float x, y, z; };
static V3 operator+(V3 a, V3 b) { return {a.x + b.x, a.y + b.y, a.z + b.z}; }
static V3 operator-(V3 a, V3 b) { return {a.x - b.x, a.y - b.y, a.z - b.z}; }
static V3 operator*(V3 a, float s) { return {a.x * s, a.y * s, a.z * s}; }
static float dot(V3 a, V3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
static V3 cross(V3 a, V3 b) { return {a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x}; }
static float len(V3 a) { return std::sqrt(dot(a, a)); }
static V3 norm(V3 a) { float l = len(a); return l > 1e-6f ? a * (1.0f / l) : V3{0, 0, 0}; }

// 3x4 OpenVR-style pose: R (3x3, columns = local axes in parent space) + t
struct Pose { float m[12]; };
static V3 col(const Pose& p, int c) { return {p.m[c], p.m[4 + c], p.m[8 + c]}; }
static V3 pos(const Pose& p) { return col(p, 3); }
static V3 rot(const Pose& p, V3 v) {
    return {p.m[0] * v.x + p.m[1] * v.y + p.m[2] * v.z,
            p.m[4] * v.x + p.m[5] * v.y + p.m[6] * v.z,
            p.m[8] * v.x + p.m[9] * v.y + p.m[10] * v.z};
}
static Pose mul(const Pose& a, const Pose& b) { // a*b
    Pose r{};
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 4; j++) {
            float s = a.m[i * 4 + 0] * b.m[0 + j] + a.m[i * 4 + 1] * b.m[4 + j] + a.m[i * 4 + 2] * b.m[8 + j];
            if (j == 3) s += a.m[i * 4 + 3];
            r.m[i * 4 + j] = s;
        }
    }
    return r;
}
static Pose yawPose(float yaw, V3 t) { // rotation about +Y
    float c = std::cos(yaw), s = std::sin(yaw);
    return Pose{{c, 0, s, t.x, 0, 1, 0, t.y, -s, 0, c, t.z}};
}
static Pose inverseRigid(const Pose& p) {
    Pose r{};
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++) r.m[i * 4 + j] = p.m[j * 4 + i];
    V3 t = pos(p);
    V3 it = rot(r, t) * -1.0f;
    r.m[3] = it.x; r.m[7] = it.y; r.m[11] = it.z;
    return r;
}

// ------------------------------------------------------------------------------------------
// Settings / log
// ------------------------------------------------------------------------------------------
struct Settings {
    float worldScale = 1.0f;     // 1 game unit ~ 1 metre
    bool  firstPerson = true;
    bool  positional = true;     // 6DOF translation
    int   headBone = 5;          // BONE_HEAD
    float headForward = 0.10f;   // metres in front of the head bone
    float headUp = 0.06f;
    float nearClip = 0.10f;
    float screenDistance = 2.5f; // virtual screen distance
    float fovMargin = 1.15f;     // extra culling margin
    bool  swapEyes = false;
    bool  flipVertical = false;  // fallback if the horizon sits too high/low
    bool  mono = false;          // debug: same image to both eyes, no alternation
    bool  paired = true;         // both eyes of a pair rendered from one head pose, submitted together
    bool  fullStereo = true;     // draw BOTH eyes every frame (smoothest); otherwise alternate eyes
    bool  motionAim = true;      // bullets come from the right controller
    float aimPitch = 0.0f;       // degrees: tilt the aim ray up(+)/down(-) relative to the controller
    bool  aimDot = true;         // red dot where you're aiming
    bool  laser = true;          // dotted laser from the muzzle along the bullet line
    bool  swingMelee = true;     // hit people by swinging the controllers
    float swingSpeed = 2.2f;     // m/s (real) a hand/weapon tip must move to count as a hit
    float meleeDamage = 1.0f;    // damage multiplier
    bool  throwByHand = true;    // grenades etc. fly where/as fast as you throw
    float throwStrength = 1.6f;  // throw speed multiplier
    bool  twoHanded = true;      // left grip on the front of a long gun aims it with both hands
    float scopeZoom = 4.f;       // sniper/camera magnification when the scope is at your eye
    bool  recoil = true;         // controller buzz per shot
    bool  realCrouch = true;     // crouch in real life = CJ crouches
    float crouchDepth = 0.35f;   // metres your head must drop
    bool  holsters = true;       // grab at shoulders/hips/chest to pick weapons
    bool  swimStrokes = true;    // breaststroke to swim
    bool  wheelSteering = true;  // both grips in a car/bike = hold the wheel/handlebars
    float wheelMaxAngle = 90.f;  // wheel turn (deg) for full lock
    bool  pipelined = true;      // hand finished frames to SteamVR without waiting on the GPU
    float shotRight = 3.f, shotUp = 2.f;   // bullet direction nudge relative to the gun (degrees)
    bool  strafe = true;         // walking sideways/backwards strafes instead of turning CJ around
    float gunRight[64], gunUp[64];  // per-weapon bullet nudge (degrees), indexed by weapon type
    bool  lockBodyWhenShooting = true;
    bool  radiosity = false;     // the game's 'trails' blur/glow post effect (ghost outlines in VR)
    bool  hideCrosshair = true;  // the game's aiming reticle (you have the red dot)
    bool  driveByByHand = true;  // right grip in vehicles = hand-aimed drive-by
    bool  lockOn = false;        // left trigger = game lock-on (off with motion aim)
    bool  snapTurn = false;      // right stick: snap instead of smooth turning
    float turnSpeed = 150.f;     // smooth turn, degrees per second at full stick
    float snapAngle = 30.f;      // snap turn step, degrees
    bool  bodyFollowsHead = true;// CJ turns to face where you look while standing
    bool  handsIK = true;        // CJ's arms follow the controllers (first person, on foot)
    bool  hideHead = true;       // hide CJ's head in first person
    float handRot[2][3] = {{0, 0, 0}, {0, 0, 0}}; // calibration (deg) for left/right hand+gun
    float handOff[3] = {0.0f, -0.02f, 0.07f};     // wrist position relative to controller (m)
    bool  manualReload = true;   // empty gun stays empty until you reload by hand
    float reloadMs = 350.f;      // time from reload gesture to gun ready
    float shoulderAssist = 0.15f;// how much the shoulder helps when reaching
    float forearmTwist = 0.5f;   // share of wrist roll taken by the forearm
    // Controller grip calibration: which way is "forward" and "up" for each controller when you
    // hold it like a gun, expressed in the controller's own tracking axes. Defaults measured from
    // the user's videos (raw -Z points ~90 deg up when held naturally). F6 measures it.
    V3    natFwd[2] = {{0, -1, 0}, {0, -1, 0}};
    V3    natUp[2]  = {{0, 0, -1}, {0, 0, -1}};
    float barrelUp = 0.06f;      // barrel line above the wrist (m)
    float barrelFwd = 0.12f;     // muzzle in front of the wrist (m)
    bool  hudPanel = true;       // HUD/radar/subtitles on a floating panel instead of in the scene
    float hudDistance = 1.5f, hudWidth = 1.6f, hudDown = 0.1f;
};
static Settings S;
static char g_dir[MAX_PATH];
static FILE* g_log;

static void Log(const char* fmt, ...) {
    if (!g_log) {
        char p[MAX_PATH];
        snprintf(p, sizeof(p), "%sGTASA_VR.log", g_dir);
        g_log = fopen(p, "w");
        if (!g_log) return;
    }
    va_list a; va_start(a, fmt);
    vfprintf(g_log, fmt, a);
    va_end(a);
    fputc('\n', g_log);
    fflush(g_log);
}

static const char* GunName(int t) {
    static const char* names[] = {"Pistol", "SilencedPistol", "DesertEagle", "Shotgun", "SawnOff", "SPAS12",
                                  "MicroUzi", "MP5", "AK47", "M4", "Tec9", "CountryRifle", "SniperRifle",
                                  "RocketLauncher", "HeatSeeker", "Flamethrower", "Minigun"};
    return (t >= 22 && t <= 38) ? names[t - 22] : nullptr;
}
static float IniF(const char* ini, const char* sec, const char* key, float def) {
    char buf[64], d[64];
    snprintf(d, sizeof(d), "%g", def);
    GetPrivateProfileStringA(sec, key, d, buf, sizeof(buf), ini);
    return (float)atof(buf);
}
static void LoadSettings() {
    char ini[MAX_PATH];
    snprintf(ini, sizeof(ini), "%sGTASA_VR.ini", g_dir);
    S.worldScale     = IniF(ini, "VR", "WorldScale", S.worldScale);
    S.firstPerson    = IniF(ini, "VR", "FirstPerson", 1) != 0;
    S.positional     = IniF(ini, "VR", "PositionalTracking", 1) != 0;
    S.headBone       = (int)IniF(ini, "VR", "HeadBone", (float)S.headBone);
    S.headForward    = IniF(ini, "VR", "HeadForward", S.headForward);
    S.headUp         = IniF(ini, "VR", "HeadUp", S.headUp);
    S.nearClip       = IniF(ini, "VR", "NearClip", S.nearClip);
    S.screenDistance = IniF(ini, "VR", "ScreenDistance", S.screenDistance);
    S.fovMargin      = IniF(ini, "VR", "CullingMargin", S.fovMargin);
    S.swapEyes       = IniF(ini, "VR", "SwapEyes", 0) != 0;
    S.flipVertical   = IniF(ini, "VR", "FlipVerticalFOV", 0) != 0;
    S.paired         = IniF(ini, "VR", "PairedEyes", 1) != 0;
    S.fullStereo     = IniF(ini, "VR", "FullStereo", 1) != 0;
    S.mono           = IniF(ini, "VR", "MonoTest", 0) != 0;
    S.motionAim      = IniF(ini, "Controls", "MotionAim", 1) != 0;
    S.aimPitch       = IniF(ini, "Controls", "AimPitch", 0);
    S.aimDot         = IniF(ini, "Controls", "AimDot", 1) != 0;
    S.laser          = IniF(ini, "Controls", "Laser", 1) != 0;
    S.swingMelee     = IniF(ini, "Controls", "SwingMelee", 1) != 0;
    S.swingSpeed     = IniF(ini, "Controls", "SwingSpeed", 2.2f);
    S.meleeDamage    = IniF(ini, "Controls", "MeleeDamage", 1.0f);
    S.throwByHand    = IniF(ini, "Controls", "ThrowByHand", 1) != 0;
    S.throwStrength  = IniF(ini, "Controls", "ThrowStrength", 1.6f);
    S.twoHanded      = IniF(ini, "Controls", "TwoHanded", 1) != 0;
    S.scopeZoom      = IniF(ini, "Controls", "ScopeZoom", 4.f);
    S.recoil         = IniF(ini, "Controls", "RecoilHaptics", 1) != 0;
    S.realCrouch     = IniF(ini, "Controls", "RealCrouch", 1) != 0;
    S.crouchDepth    = IniF(ini, "Controls", "CrouchDepth", 0.35f);
    S.holsters       = IniF(ini, "Controls", "Holsters", 1) != 0;
    S.swimStrokes    = IniF(ini, "Controls", "SwimStrokes", 1) != 0;
    S.wheelSteering  = IniF(ini, "Controls", "WheelSteering", 1) != 0;
    S.wheelMaxAngle  = IniF(ini, "Controls", "WheelMaxAngle", 90.f);
    S.pipelined      = IniF(ini, "VR", "PipelinedSubmit", 1) != 0;
    S.shotRight      = IniF(ini, "Controls", "ShotRight", S.shotRight);
    S.shotUp         = IniF(ini, "Controls", "ShotUp", S.shotUp);
    S.strafe         = IniF(ini, "Controls", "Strafe", 1) != 0;
    S.lockBodyWhenShooting = IniF(ini, "Controls", "LockBodyWhenShooting", 1) != 0;
    S.radiosity      = IniF(ini, "VR", "TrailsEffect", 0) != 0;
    S.hideCrosshair  = IniF(ini, "HUD", "HideCrosshair", 1) != 0;
    S.driveByByHand  = IniF(ini, "Controls", "DriveByByHand", 1) != 0;
    for (int t = 0; t < 64; t++) {
        S.gunRight[t] = S.shotRight; S.gunUp[t] = S.shotUp;
        if (const char* n = GunName(t)) {
            char sec[48]; snprintf(sec, sizeof(sec), "Gun.%s", n);
            S.gunRight[t] = IniF(ini, sec, "ShotRight", S.shotRight);
            S.gunUp[t]    = IniF(ini, sec, "ShotUp", S.shotUp);
        }
    }
    S.lockOn         = IniF(ini, "Controls", "LeftTriggerLockOn", 0) != 0;
    S.snapTurn       = IniF(ini, "Controls", "SnapTurn", 0) != 0;
    S.turnSpeed      = IniF(ini, "Controls", "TurnSpeed", S.turnSpeed);
    S.snapAngle      = IniF(ini, "Controls", "SnapTurnAngle", S.snapAngle);
    S.bodyFollowsHead= IniF(ini, "Controls", "BodyFollowsHead", 1) != 0;
    S.manualReload   = IniF(ini, "Controls", "ManualReload", 1) != 0;
    S.reloadMs       = IniF(ini, "Controls", "ReloadTimeMs", S.reloadMs);
    S.handsIK        = IniF(ini, "Body", "HandsFollowControllers", 1) != 0;
    S.hideHead       = IniF(ini, "Body", "HideHead", 1) != 0;
    S.shoulderAssist = IniF(ini, "Body", "ShoulderAssist", S.shoulderAssist);
    S.forearmTwist   = IniF(ini, "Body", "ForearmTwist", S.forearmTwist);
    S.hudPanel       = IniF(ini, "HUD", "HudPanel", 1) != 0;
    S.hudDistance    = IniF(ini, "HUD", "Distance", S.hudDistance);
    S.hudWidth       = IniF(ini, "HUD", "Width", S.hudWidth);
    S.hudDown        = IniF(ini, "HUD", "Down", S.hudDown);
    {
        const char* hn[2] = {"Left", "Right"};
        char k[32];
        for (int h = 0; h < 2; h++) {
            float* f = &S.natFwd[h].x; float* u = &S.natUp[h].x;
            for (int i = 0; i < 3; i++) {
                snprintf(k, sizeof(k), "%sFwd%c", hn[h], 'X' + i); f[i] = IniF(ini, "Calibration", k, f[i]);
                snprintf(k, sizeof(k), "%sUp%c", hn[h], 'X' + i);  u[i] = IniF(ini, "Calibration", k, u[i]);
            }
        }
    }
    {
        const char* keys[2][3] = {{"LeftHandRotX", "LeftHandRotY", "LeftHandRotZ"}, {"RightHandRotX", "RightHandRotY", "RightHandRotZ"}};
        for (int h = 0; h < 2; h++) for (int k = 0; k < 3; k++) S.handRot[h][k] = IniF(ini, "Body", keys[h][k], 0);
        S.handOff[0] = IniF(ini, "Body", "HandOffsetX", S.handOff[0]);
        S.handOff[1] = IniF(ini, "Body", "HandOffsetY", S.handOff[1]);
        S.handOff[2] = IniF(ini, "Body", "HandOffsetZ", S.handOff[2]);
    }
    Log("Settings: scale=%.2f firstPerson=%d positional=%d headBone=%d near=%.2f",
        S.worldScale, S.firstPerson, S.positional, S.headBone, S.nearClip);
}

// ------------------------------------------------------------------------------------------
// Patching helpers
// ------------------------------------------------------------------------------------------
static void WriteMem(uintptr_t addr, const void* data, size_t n) {
    DWORD old;
    VirtualProtect((void*)addr, n, PAGE_EXECUTE_READWRITE, &old);
    memcpy((void*)addr, data, n);
    VirtualProtect((void*)addr, n, old, &old);
    FlushInstructionCache(GetCurrentProcess(), (void*)addr, n);
}
// Redirect an E8 call at `site` to `fn`; returns the previous target (could be another mod's hook).
static uintptr_t RedirectCall(uintptr_t site, void* fn) {
    uint8_t op = Mem<uint8_t>(site);
    if (op != 0xE8 && op != 0xE9) { Log("! call site %08X is not a CALL/JMP (byte %02X), skipped", site, op); return 0; }
    uintptr_t prev = site + 5 + Mem<int32_t>(site + 1);
    int32_t rel = (int32_t)((uintptr_t)fn - (site + 5));
    WriteMem(site + 1, &rel, 4);
    Log("Hooked call %08X (previous target %08X)", site, prev);
    return prev;
}

// ------------------------------------------------------------------------------------------
// VR state
// ------------------------------------------------------------------------------------------
struct EyeInfo { float l, r, t, b; Pose eyeToHead; float u0, v0, u1, v1; };
static struct {
    bool  tried = false, ok = false;
    EyeInfo eye[2];
    float vwx = 1, vwy = 1;          // RW view window we force (tan half-angles)
    int   bbW = 0, bbH = 0;

    Pose  hmd{};                     // latest HMD pose (absolute tracking space)
    bool  hmdValid = false;
    Pose  origin{};                  // recenter transform (yaw + position)
    bool  needRecenter = true;

    int   nextEye = 0;               // eye the next rendered frame is for
    bool  frameHasCam = false;       // our camera hook ran this frame
    int   frameEye = 0;
    Pose  framePose{};
    Pose  lastPose[2]{};
    bool  eyeFilled[2] = {false, false};   // legacy (unpaired) mode

    // Paired mode: render L then R with the SAME head pose into work textures,
    // then publish the finished pair to the display textures with that pose.
    Pose  pairPose{};
    bool  pairHas[2] = {false, false};
    Pose  dispPose{};
    bool  dispValid = false, dispMono = false;

    // How VR space maps into the game world this frame (set by the camera hook)
    bool  full = false;              // this frame uses full stereo
    float rMat[16] = {};             // right-eye camera matrix (CMatrix layout) for the second pass
    bool  rValid = false;
    bool  wValid = false;
    V3    wBase{}, wR{}, wF{}, wU{};
    bool  onFootFP = false;          // first person, on foot, normal play
    bool  inVehFP = false;           // first person, in a vehicle
    bool  driveBy = false;           // right grip held in a vehicle: gun up, hand-aimed drive-by
    V3    vehRight{};                // vehicle's right vector (world)
    bool  bodyYawValid = false;
    float bodyYaw = 0;               // our own body heading on foot (GTA heading, radians)
    bool  snapLatch = false;
    V3    gunPos{}, gunDir{}, gunUp{};
    int   gunFrame = -100;
    double lastCamMs = 0;
    // hand motion (VR space relative to the recenter origin: x right, y up, z back; metres, m/s)
    V3    handRel[2]{}, handVel[2]{};
    bool  hmv[2] = {false, false};
    bool  twoHand = false;           // left hand holding the front of a long gun
    bool  scoped = false;            // sniper/camera scope at the eye: view magnified
    float zoom = 4.f;
    bool  standValid = false;        // real-crouch: standing head height
    float standY = 0;
    float crouchComp = 0;            // metres added back to the view/hands while CJ is crouched

    bool  flatMode = false;          // user toggled virtual screen
    bool  overlayShown = false;
    bool  placeScreen = true;        // (re)position the virtual screen in front of you
} V;

// Per-second diagnostics
static struct {
    DWORD t0 = 0;
    int presents = 0, camHooks = 0, cap[2] = {0, 0}, noCam = 0, sameEyeTwice = 0, lastCapEye = -1;
    double capMs = 0, waitMs = 0, frameMs = 0;
} St;
static double NowMs() {
    static LARGE_INTEGER f; LARGE_INTEGER c;
    if (!f.QuadPart) QueryPerformanceFrequency(&f);
    QueryPerformanceCounter(&c);
    return (double)c.QuadPart * 1000.0 / (double)f.QuadPart;
}
static void StatsTick() {
    DWORD now = GetTickCount();
    if (!St.t0) St.t0 = now;
    if (now - St.t0 < 5000) return;
    double sec = (now - St.t0) / 1000.0;
    int n = St.presents ? St.presents : 1;
    Log("stats: %.0f fps | camera hooks %.0f/s | captures L %.0f/s R %.0f/s | frames w/o camera %d | same eye twice %d | capture %.1f ms, wait %.1f ms, frame %.1f ms%s",
        St.presents / sec, St.camHooks / sec, St.cap[0] / sec, St.cap[1] / sec, St.noCam, St.sameEyeTwice,
        St.capMs / n, St.waitMs / n, St.frameMs / n, S.mono ? " [MONO]" : (V.full ? " [FULL STEREO]" : (S.paired ? " [paired]" : " [unpaired]")));
    int lc = St.lastCapEye;
    St = {};
    St.t0 = now; St.lastCapEye = lc;
}

// D3D resources
static IDirect3DSurface9* g_rt = nullptr;    // non-MSAA copy of the back buffer
static IDirect3DSurface9* g_sys = nullptr;   // system-memory readback
static ID3D11Device* g_d11 = nullptr;
static ID3D11DeviceContext* g_ctx = nullptr;
static ID3D11Texture2D* g_eyeTex[2] = {nullptr, nullptr};   // work (being rendered)
static ID3D11Texture2D* g_dispTex[2] = {nullptr, nullptr};  // displayed
static ID3D11Texture2D* g_screenTex = nullptr;
static UINT g_texW = 0, g_texH = 0;

static void ComputeViewWindow() {
    float needX = 0, needY = 0;
    for (int e = 0; e < 2; e++) {
        needX = std::fmax(needX, std::fmax(std::fabs(V.eye[e].l), std::fabs(V.eye[e].r)));
        needY = std::fmax(needY, std::fmax(std::fabs(V.eye[e].t), std::fabs(V.eye[e].b)));
    }
    float aspect = V.bbW > 0 && V.bbH > 0 ? (float)V.bbW / V.bbH : 16.f / 9.f;
    V.vwy = std::fmax(needY, needX / aspect);
    V.vwx = V.vwy * aspect;
    for (int e = 0; e < 2; e++) {
        EyeInfo& E = V.eye[e];
        // OpenVR's "top"/"bottom" are the y-up tangent range [min, max] (top = lower edge).
        // Texture v runs downward, so the upper edge (yMax) maps to the smaller v.
        float yMin = std::fmin(E.t, E.b), yMax = std::fmax(E.t, E.b);
        if (S.flipVertical) { float t = -yMin; yMin = -yMax; yMax = t; }
        E.u0 = (E.l + V.vwx) / (2 * V.vwx);
        E.u1 = (E.r + V.vwx) / (2 * V.vwx);
        E.v0 = (V.vwy - yMax) / (2 * V.vwy);
        E.v1 = (V.vwy - yMin) / (2 * V.vwy);
    }
    Log("Back buffer %dx%d, view window %.3f x %.3f (h-FOV %.1f deg), L uv [%.3f..%.3f]x[%.3f..%.3f]",
        V.bbW, V.bbH, V.vwx, V.vwy, 2 * std::atan(V.vwx) * 57.2958f,
        V.eye[0].u0, V.eye[0].u1, V.eye[0].v0, V.eye[0].v1);
    if (V.eye[0].u1 - V.eye[0].u0 < 0.5f)
        Log("  note: only %.0f%% of the frame width reaches each eye. A taller resolution (e.g. 1920x1440 or 2560x1440) gives sharper VR.",
            (V.eye[0].u1 - V.eye[0].u0) * 100);
}

static void Recenter() {
    if (!V.hmdValid) return;
    V3 f = col(V.hmd, 2) * -1.0f;
    float yaw = std::atan2(-f.x, -f.z);
    V.origin = yawPose(yaw, pos(V.hmd));
    V.needRecenter = false;
    V.placeScreen = true;
    V.standValid = false;
    Log("Recentered");
}

// Head pose relative to the recenter origin, for an eye (VR space, metres)
static Pose EyePoseRelative(int eye, const Pose& hmd) {
    Pose rel = mul(inverseRigid(V.origin), hmd);
    if (!S.positional) { rel.m[3] = rel.m[7] = rel.m[11] = 0; }
    return mul(rel, V.eye[eye].eyeToHead);
}

// ------------------------------------------------------------------------------------------
// Camera hook: runs inside CCamera::Process, after the game decided its camera and FOV,
// right before CalculateDerivedValues + CopyCameraMatrixToRWCam.
// ------------------------------------------------------------------------------------------
typedef void (__thiscall* CalcDerived_t)(void*, int, int);
typedef void* (__cdecl* FindPlayerPed_t)(int);
typedef void (__thiscall* GetBonePos_t)(void*, V3*, int, int);
typedef void* (__cdecl* RwCamSetVW_t)(void*, const float*);
typedef void* (__cdecl* RwCamSetNear_t)(void*, float);
typedef void (__cdecl* CameraSize_t)(void*, void*, float, float);

static uintptr_t g_prevCalcDerived, g_prevCameraSizeA, g_prevCameraSizeB;

enum : int { BTN_MENU = 1, BTN_GRIP = 2, BTN_A = 7, BTN_STICK = 32, BTN_TRIGGER = 33 };

struct Hand {
    bool valid = false, poseValid = false;
    uint64_t pressed = 0, prev = 0;
    float ax[10] = {};
    Pose pose{};      // corrected: -Z = where you point, +Y = up, as you hold it
    Pose raw{};       // as reported by SteamVR
    bool down(int b) const { return (pressed >> b) & 1; }
    bool justDown(int b) const { return ((pressed >> b) & 1) && !((prev >> b) & 1); }
    float trigger() const { return std::fmax(ax[2], down(BTN_TRIGGER) ? 1.f : 0.f); }
    float grip() const { return std::fmax(ax[4], down(BTN_GRIP) ? 1.f : 0.f); }
    float sx() const { return std::fabs(ax[0]) > 0.15f ? ax[0] : 0.f; }
    float sy() const { return std::fabs(ax[1]) > 0.15f ? ax[1] : 0.f; }
};
static Hand H[2];                                  // 0 = left, 1 = right

static void AfterCameraHook();
static void DrawAimDot();
static bool HoldingGun();
static int PlayerWeaponType();
static bool g_aimHeld = false;
static bool g_shotRequested = false;   // F5: save what both eyes see   // aim button (R1) being held for the player this frame
static void BodyEdits();
static void ReloadTick();
static void MeleeTick();
static void ScopeTick();
static void FootExtras(bool& holsterGrab, bool& leftNearGun);
static float WheelSteer(bool& wheel, bool& bike, bool& wheelOK);

static bool VRActiveInGame() {
    return V.ok && V.hmdValid && !V.flatMode && Mem<int>(game::GameState) == 9 && !Mem<uint8_t>(game::MenuActive);
}

static void ApplyHeadToCamera() {
    float* M = &Mem<float>(game::Cam_Matrix);
    V3 R{M[0], M[1], M[2]}, F{M[4], M[5], M[6]}, U{M[8], M[9], M[10]}, P{M[12], M[13], M[14]};
    float rightSign = dot(R, cross(F, U)) < 0 ? -1.0f : 1.0f; // game's "right" may point left

    bool cutscene = Mem<uint8_t>(game::Cam_WideScreenOn) != 0;
    V3 bf, bu, br, base = P;
    V3 flat{F.x, F.y, 0};
    uint8_t* pedP = (uint8_t*)((FindPlayerPed_t)game::fn_FindPlayerPed)(-1);
    uint8_t* vehP = (uint8_t*)((void* (__cdecl*)(int, int))0x56E0D0)(-1, 0);   // FindPlayerVehicle
    bool fp = S.firstPerson && !cutscene && pedP;
    double nowMs = NowMs();
    float dt = V.lastCamMs > 0 ? (float)std::fmin(0.1, (nowMs - V.lastCamMs) / 1000.0) : 0.f;
    V.lastCamMs = nowMs;
    V.onFootFP = fp && !vehP;
    V.inVehFP = fp && vehP;
    if (vehP && *(float**)(vehP + 0x14)) { float* vm = *(float**)(vehP + 0x14); V.vehRight = {vm[0], vm[1], vm[2]}; }

    if (V.onFootFP) {
        // Our own body heading: right stick turns it, game camera no longer matters on foot
        if (!V.bodyYawValid) { V.bodyYaw = *(float*)(pedP + 0x558); V.bodyYawValid = true; }
        float sx = H[1].valid ? H[1].sx() : 0.f;
        if (S.snapTurn) {
            if (!V.snapLatch && std::fabs(sx) > 0.7f) { V.bodyYaw -= (sx > 0 ? 1 : -1) * S.snapAngle * 0.0174533f; V.snapLatch = true; }
            if (std::fabs(sx) < 0.3f) V.snapLatch = false;
        } else {
            V.bodyYaw -= sx * S.turnSpeed * 0.0174533f * dt;
        }
        bf = {-std::sin(V.bodyYaw), std::cos(V.bodyYaw), 0}; bu = {0, 0, 1};
    } else if (fp && vehP && *(float**)(vehP + 0x14)) {
        // In a vehicle: look relative to the vehicle's heading (yaw only, for comfort)
        float* vm = *(float**)(vehP + 0x14);
        V3 vf{vm[4], vm[5], 0};
        if (len(vf) < 0.05f) vf = flat;
        bf = norm(vf); bu = {0, 0, 1};
        V.bodyYawValid = false;
    } else if (!cutscene && len(flat) > 0.05f) {
        bf = norm(flat); bu = {0, 0, 1};             // yaw only: your head supplies pitch/roll
        V.bodyYawValid = false;
    } else {
        bf = norm(F); bu = norm(U);                   // scripted shots: keep the director's framing
        V.bodyYawValid = false;
    }
    br = norm(cross(bf, bu));                         // screen-right

    if (S.firstPerson && !cutscene) {
        void* ped = ((FindPlayerPed_t)game::fn_FindPlayerPed)(-1);
        if (ped) {
            V3 head{0, 0, 0};
            ((GetBonePos_t)game::fn_GetBonePosition)(ped, &head, S.headBone, 1);
            if (len(head) > 1.0f) base = head + bf * S.headForward + bu * S.headUp;
        }
    }

    St.camHooks++;
    V.full = S.fullStereo && !S.mono;
    int eye = V.full ? 0 : V.nextEye;
    int vrEye = S.swapEyes ? 1 - eye : eye;
    if (V.full) V.pairHas[0] = V.pairHas[1] = false;
    // In paired mode the second eye of a pair reuses the first eye's head pose
    if (!S.paired || S.mono || (!V.pairHas[0] && !V.pairHas[1])) V.pairPose = V.hmd;
    const Pose& usePose = V.pairPose;
    Pose e = EyePoseRelative(vrEye, usePose);
    {
        bool ducked = V.onFootFP && pedP && (pedP[0x46F] & 4);              // CPed::bIsDucking
        float y = pos(mul(inverseRigid(V.origin), V.hmd)).y;
        V.crouchComp = (S.realCrouch && S.positional && ducked && V.standValid) ? std::fmax(0.f, V.standY - y) : 0.f;
    }
    e.m[7] += V.crouchComp;
    if (S.mono) { Pose h = mul(inverseRigid(V.origin), usePose); if (!S.positional) h.m[3] = h.m[7] = h.m[11] = 0; e = h; }
    auto toWorld = [&](V3 v) { return br * v.x + bf * (-v.z) + bu * v.y; };
    V3 nf = norm(toWorld(col(e, 2) * -1.0f));
    V3 nu = norm(toWorld(col(e, 1)));
    V3 nr = cross(nf, nu) * rightSign;
    V3 np = base + toWorld(pos(e)) * S.worldScale;

    // Shooting / strafing: the game's gun code swings CJ toward its aim direction. Freeze his body
    // heading from the moment you start until you stop, so shoulders/arms don't shift under you.
    {
        static bool locked = false;
        static float lockedHeading = 0;
        bool busy = V.onFootFP && S.lockBodyWhenShooting && HoldingGun() &&
                    (H[1].trigger() > 0.3f || g_aimHeld);
        if (busy && !locked) { lockedHeading = *(float*)(pedP + 0x558); locked = true; }
        if (!busy) locked = false;
        if (locked) {
            *(float*)(pedP + 0x558) = lockedHeading;
            *(float*)(pedP + 0x55C) = lockedHeading;
            if (float* pm = *(float**)(pedP + 0x14)) {       // this frame's matrix too (skeleton is posed after this)
                float c = std::cos(lockedHeading), sn = std::sin(lockedHeading);
                pm[0] = c;   pm[1] = sn; pm[2] = 0;
                pm[4] = -sn; pm[5] = c;  pm[6] = 0;
                pm[8] = 0;   pm[9] = 0;  pm[10] = 1;
            }
        } else if (V.onFootFP && S.bodyFollowsHead && H[0].sx() == 0.f && H[0].sy() == 0.f && len(V3{nf.x, nf.y, 0}) > 0.2f) {
            *(float*)(pedP + 0x55C) = std::atan2(-nf.x, nf.y);   // CJ turns to face where you look
        }
    }

    M[0] = nr.x; M[1] = nr.y; M[2] = nr.z;
    M[4] = nf.x; M[5] = nf.y; M[6] = nf.z;
    M[8] = nu.x; M[9] = nu.y; M[10] = nu.z;
    M[12] = np.x; M[13] = np.y; M[14] = np.z;

    if (!S.radiosity) Mem<uint8_t>(0xC402CC) = 0;          // CPostEffects::m_bRadiosity ("trails")

    // On foot we drive the view ourselves, but the game's own (hidden) camera still decides what
    // "forward" means for aiming/strafing movement. Keep it pointing where you look, so pulling
    // the stick back while strafing really walks you backwards.
    if (V.onFootFP && len(V3{nf.x, nf.y, 0}) > 0.1f) {
        uint8_t active = Mem<uint8_t>(game::TheCamera + 0x59);
        if (active < 3) {
            uintptr_t cam = game::TheCamera + 0x174 + active * 0x238;
            Mem<float>(cam + 0xBC) = std::atan2(-nf.y, -nf.x);   // CCam::m_fHorizontalAngle (Beta)
        }
    }

    if (V.full) {   // second eye for the extra render pass
        Pose e2 = EyePoseRelative(1 - vrEye, usePose);
        e2.m[7] += V.crouchComp;
        V3 f2 = norm(toWorld(col(e2, 2) * -1.0f)), u2 = norm(toWorld(col(e2, 1)));
        V3 r2 = cross(f2, u2) * rightSign, p2 = base + toWorld(pos(e2)) * S.worldScale;
        float* R = V.rMat;
        R[0] = r2.x; R[1] = r2.y; R[2] = r2.z; R[3] = M[3];
        R[4] = f2.x; R[5] = f2.y; R[6] = f2.z; R[7] = M[7];
        R[8] = u2.x; R[9] = u2.y; R[10] = u2.z; R[11] = M[11];
        R[12] = p2.x; R[13] = p2.y; R[14] = p2.z; R[15] = M[15];
        V.rValid = true;
    } else {
        V.rValid = false;
    }

    // Widen the game's FOV so its culling covers the whole lens view
    Mem<float>(game::Draw_FOV) = std::fmin(170.f, 2 * std::atan(V.vwx * S.fovMargin) * 57.2958f);
    if (V.bbW > 0 && V.bbH > 0) Mem<float>(game::Draw_Aspect) = (float)V.bbW / V.bbH;

    V.wValid = true; V.wBase = base; V.wR = br; V.wF = bf; V.wU = bu;
    AfterCameraHook();

    V.frameHasCam = true;
    V.frameEye = vrEye;
    V.framePose = usePose;
}

static void __fastcall hkCalcDerived(void* cam, void* /*edx*/, int bForMirror, int bOriented) {
    if (VRActiveInGame() && !bForMirror) ApplyHeadToCamera();
    ((CalcDerived_t)g_prevCalcDerived)(cam, bForMirror, bOriented);
}

static void ForceViewWindow(void* cam) {
    if (!VRActiveInGame() || cam != Mem<void*>(game::Scene_RwCamera)) return;
    BodyEdits();
    float z = V.scoped ? std::fmax(1.f, V.zoom) : 1.f;
    float vw[2] = {V.vwx / z, V.vwy / z};
    ((RwCamSetVW_t)game::fn_RwCamSetViewWin)(cam, vw);
    if (S.firstPerson && !Mem<uint8_t>(game::Cam_WideScreenOn))
        ((RwCamSetNear_t)game::fn_RwCamSetNearClip)(cam, S.nearClip);
}
static void __cdecl hkCameraSizeA(void* cam, void* rect, float vw, float aspect) {
    ((CameraSize_t)g_prevCameraSizeA)(cam, rect, vw, aspect);
    ForceViewWindow(cam);
}
static void __cdecl hkCameraSizeB(void* cam, void* rect, float vw, float aspect) {
    ((CameraSize_t)g_prevCameraSizeB)(cam, rect, vw, aspect);
    ForceViewWindow(cam);
}

// ------------------------------------------------------------------------------------------
// D3D9 -> D3D11 -> SteamVR
// ------------------------------------------------------------------------------------------
static void ReleaseD3D9Copies() {
    if (g_rt) { g_rt->Release(); g_rt = nullptr; }
    if (g_sys) { g_sys->Release(); g_sys = nullptr; }
}
static void ReleaseD3D11Textures() {
    for (auto*& t : g_eyeTex) if (t) { t->Release(); t = nullptr; }
    for (auto*& t : g_dispTex) if (t) { t->Release(); t = nullptr; }
    if (g_screenTex) { g_screenTex->Release(); g_screenTex = nullptr; }
    g_texW = g_texH = 0;
    V.eyeFilled[0] = V.eyeFilled[1] = false;
    V.pairHas[0] = V.pairHas[1] = false;
    V.dispValid = false;
}

static bool InitD3D11() {
    typedef HRESULT (WINAPI* CreateFactory_t)(REFIID, void**);
    HMODULE dxgi = LoadLibraryA("dxgi.dll");
    HMODULE d11 = LoadLibraryA("d3d11.dll");
    if (!dxgi || !d11) { Log("! dxgi.dll / d3d11.dll not available"); return false; }
    auto createFactory = (CreateFactory_t)GetProcAddress(dxgi, "CreateDXGIFactory1");
    auto createDevice = (PFN_D3D11_CREATE_DEVICE)GetProcAddress(d11, "D3D11CreateDevice");
    if (!createFactory || !createDevice) { Log("! D3D11 entry points missing"); return false; }

    IDXGIAdapter1* adapter = nullptr;
    IDXGIFactory1* factory = nullptr;
    int idx = vr_adapter_index();
    if (SUCCEEDED(createFactory(__uuidof(IDXGIFactory1), (void**)&factory))) {
        if (idx >= 0) factory->EnumAdapters1((UINT)idx, &adapter);
        factory->Release();
    }
    D3D_FEATURE_LEVEL fl;
    HRESULT hr = createDevice(adapter, adapter ? D3D_DRIVER_TYPE_UNKNOWN : D3D_DRIVER_TYPE_HARDWARE, nullptr, 0,
                              nullptr, 0, D3D11_SDK_VERSION, &g_d11, &fl, &g_ctx);
    if (adapter) adapter->Release();
    if (FAILED(hr)) { Log("! D3D11CreateDevice failed %08lX", hr); return false; }
    Log("D3D11 bridge device created on adapter %d", idx);
    return true;
}

static ID3D11Texture2D* MakeTex(UINT w, UINT h) {
    D3D11_TEXTURE2D_DESC d{};
    d.Width = w; d.Height = h; d.MipLevels = 1; d.ArraySize = 1;
    d.Format = DXGI_FORMAT_B8G8R8A8_UNORM;
    d.SampleDesc.Count = 1;
    d.Usage = D3D11_USAGE_DEFAULT;
    d.BindFlags = D3D11_BIND_SHADER_RESOURCE;
    ID3D11Texture2D* t = nullptr;
    if (FAILED(g_d11->CreateTexture2D(&d, nullptr, &t))) return nullptr;
    return t;
}

// Copy the current back buffer into `dst` (D3D11). Returns false on failure.
static bool CaptureBackBuffer(IDirect3DDevice9* dev, ID3D11Texture2D* dst) {
    IDirect3DSurface9* bb = nullptr;
    if (FAILED(dev->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &bb))) return false;
    D3DSURFACE_DESC d;
    bb->GetDesc(&d);
    bool ok = false;
    do {
        if (!g_rt && FAILED(dev->CreateRenderTarget(d.Width, d.Height, D3DFMT_X8R8G8B8, D3DMULTISAMPLE_NONE, 0, FALSE, &g_rt, nullptr))) break;
        if (!g_sys && FAILED(dev->CreateOffscreenPlainSurface(d.Width, d.Height, D3DFMT_X8R8G8B8, D3DPOOL_SYSTEMMEM, &g_sys, nullptr))) break;
        if (FAILED(dev->StretchRect(bb, nullptr, g_rt, nullptr, D3DTEXF_NONE))) break;
        if (FAILED(dev->GetRenderTargetData(g_rt, g_sys))) break;
        D3DLOCKED_RECT lr;
        if (FAILED(g_sys->LockRect(&lr, nullptr, 0))) break;
        for (UINT y = 0; y < d.Height; y++) {                 // X8 -> opaque alpha
            uint32_t* row = (uint32_t*)((uint8_t*)lr.pBits + y * lr.Pitch);
            for (UINT x = 0; x < d.Width; x++) row[x] |= 0xFF000000u;
        }
        g_ctx->UpdateSubresource(dst, 0, nullptr, lr.pBits, lr.Pitch, 0);
        g_sys->UnlockRect();
        ok = true;
    } while (0);
    bb->Release();
    return ok;
}

static bool EnsureResources(IDirect3DDevice9* dev) {
    IDirect3DSurface9* bb = nullptr;
    if (FAILED(dev->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &bb))) return false;
    D3DSURFACE_DESC d;
    bb->GetDesc(&d);
    bb->Release();
    if (d.Width != g_texW || d.Height != g_texH) {
        ReleaseD3D9Copies();
        ReleaseD3D11Textures();
        g_eyeTex[0] = MakeTex(d.Width, d.Height);
        g_eyeTex[1] = MakeTex(d.Width, d.Height);
        g_dispTex[0] = MakeTex(d.Width, d.Height);
        g_dispTex[1] = MakeTex(d.Width, d.Height);
        g_screenTex = MakeTex(d.Width, d.Height);
        if (!g_eyeTex[0] || !g_eyeTex[1] || !g_dispTex[0] || !g_dispTex[1] || !g_screenTex) { Log("! failed to create D3D11 textures"); return false; }
        g_texW = d.Width; g_texH = d.Height;
        V.bbW = d.Width; V.bbH = d.Height;
        ComputeViewWindow();
    }
    return true;
}

static bool InitVR() {
    V.tried = true;
    char err[256] = "", dll[MAX_PATH];
    snprintf(dll, sizeof(dll), "%sopenvr_api.dll", g_dir);
    if (!vr_init(dll, err, sizeof(err))) { Log("! VR init failed: %s", err); return false; }
    for (int e = 0; e < 2; e++) {
        vr_projection_raw(e, &V.eye[e].l, &V.eye[e].r, &V.eye[e].t, &V.eye[e].b);
        vr_eye_to_head(e, V.eye[e].eyeToHead.m);
        Log("Eye %d: tan L %.3f R %.3f T %.3f B %.3f, offset %.4f %.4f %.4f", e,
            V.eye[e].l, V.eye[e].r, V.eye[e].t, V.eye[e].b,
            V.eye[e].eyeToHead.m[3], V.eye[e].eyeToHead.m[7], V.eye[e].eyeToHead.m[11]);
    }
    uint32_t rw, rh;
    vr_recommended_size(&rw, &rh);
    Log("SteamVR recommended per-eye size %ux%u", rw, rh);
    if (!InitD3D11()) return false;
    vr_overlay_create();
    Log("VR ready");
    return true;
}

// ------------------------------------------------------------------------------------------
// Hotkeys
// ------------------------------------------------------------------------------------------
static bool KeyPressed(int vk) {
    static bool down[256];
    bool now = (GetAsyncKeyState(vk) & 0x8000) != 0;
    bool pressed = now && !down[vk];
    down[vk] = now;
    return pressed;
}
static bool GameHasFocus() {
    DWORD pid = 0;
    GetWindowThreadProcessId(GetForegroundWindow(), &pid);
    return pid == GetCurrentProcessId();
}

// F6: hold both controllers like you're aiming a gun straight ahead (level), then press F6.
// We record which of the controller's own axes point forward/up in that grip and save it.
static void CalibrateControllers() {
    if (!V.hmdValid) return;
    V3 hf = col(V.hmd, 2) * -1.0f; hf.y = 0;
    if (len(hf) < 0.1f) return;
    hf = norm(hf);
    V3 up{0, 1, 0};
    char ini[MAX_PATH], val[32], key[32];
    snprintf(ini, sizeof(ini), "%sGTASA_VR.ini", g_dir);
    const char* hn[2] = {"Left", "Right"};
    for (int h = 0; h < 2; h++) {
        if (!H[h].poseValid) continue;
        const Pose& r = H[h].raw;
        // inverse rotation = transpose
        auto inv = [&](V3 v) { return V3{dot(col(r, 0), v), dot(col(r, 1), v), dot(col(r, 2), v)}; };
        V3 f = norm(inv(hf)), u = inv(up);
        u = norm(u - f * dot(u, f));
        S.natFwd[h] = f; S.natUp[h] = u;
        const float* fv = &f.x; const float* uv = &u.x;
        for (int i = 0; i < 3; i++) {
            snprintf(key, sizeof(key), "%sFwd%c", hn[h], 'X' + i); snprintf(val, sizeof(val), "%.4f", fv[i]);
            WritePrivateProfileStringA("Calibration", key, val, ini);
            snprintf(key, sizeof(key), "%sUp%c", hn[h], 'X' + i);  snprintf(val, sizeof(val), "%.4f", uv[i]);
            WritePrivateProfileStringA("Calibration", key, val, ini);
        }
        Log("Calibrated %s controller: forward (%.2f %.2f %.2f) up (%.2f %.2f %.2f)", hn[h], f.x, f.y, f.z, u.x, u.y, u.z);
        vr_haptic(h, 3000);
    }
}

// Calibration needs both hands in the aiming pose, so it never fires straight from the keyboard:
//  * F6 starts a 3-second countdown (one buzz per second, long buzz when captured), or
//  * hold BOTH thumbstick clicks for 1 second while aiming.
static double g_calibAt = 0;
static int g_calibBuzz = 0;
static void StartCalibrationCountdown() {
    g_calibAt = NowMs() + 3000; g_calibBuzz = 3;
    Log("Calibration in 3 seconds: hold both controllers like you're aiming straight ahead");
}
static void CalibrationTick() {
    double now = NowMs();
    static double bothSticksSince = 0;
    bool both = H[0].down(BTN_STICK) && H[1].down(BTN_STICK);
    if (both) { if (bothSticksSince == 0) bothSticksSince = now; }
    else bothSticksSince = 0;
    if (bothSticksSince > 0 && now - bothSticksSince > 1000) {
        bothSticksSince = 0; g_calibAt = 0;
        CalibrateControllers();
        return;
    }
    if (g_calibAt == 0) return;
    if (g_calibBuzz > 0 && now >= g_calibAt - g_calibBuzz * 1000.0) {   // one tick per second
        vr_haptic(0, 1000); vr_haptic(1, 1000);
        g_calibBuzz--;
    }
    if (now >= g_calibAt) { g_calibAt = 0; CalibrateControllers(); }
}

static void PollKeys() {
    if (!GameHasFocus()) return;
    if (KeyPressed(VK_F8))  { V.flatMode = !V.flatMode; Log("Virtual screen mode %s", V.flatMode ? "on" : "off"); }
    if (KeyPressed(VK_F9))  V.needRecenter = true;
    if (KeyPressed(VK_F10)) { S.firstPerson = !S.firstPerson; Log("First person %s", S.firstPerson ? "on" : "off"); }
    if (KeyPressed(VK_F11)) { S.positional = !S.positional; Log("Positional tracking %s", S.positional ? "on" : "off"); }
    if (KeyPressed(VK_PRIOR)) { S.aimPitch += 5; Log("AimPitch %.0f", S.aimPitch); }
    if (KeyPressed(VK_NEXT))  { S.aimPitch -= 5; Log("AimPitch %.0f", S.aimPitch); }
    if (KeyPressed(VK_F6)) StartCalibrationCountdown();
    if (KeyPressed(VK_F5)) { g_shotRequested = true; Log("Eye screenshot requested"); }
    if (GetAsyncKeyState(VK_CONTROL) & 0x8000) {   // Ctrl+arrows: nudge where bullets go, 1 degree per press (saved)
        // adjusts ONLY the gun you're holding; each gun is saved in its own [Gun.<name>] section
        int t = PlayerWeaponType() & 63;
        const char* name = GunName(t);
        bool ch = false;
        if (KeyPressed(VK_RIGHT)) { S.gunRight[t] += 1; ch = true; }
        if (KeyPressed(VK_LEFT))  { S.gunRight[t] -= 1; ch = true; }
        if (KeyPressed(VK_UP))    { S.gunUp[t] += 1; ch = true; }
        if (KeyPressed(VK_DOWN))  { S.gunUp[t] -= 1; ch = true; }
        if (ch && name) {
            char ini[MAX_PATH], v[32], sec[48];
            snprintf(ini, sizeof(ini), "%sGTASA_VR.ini", g_dir);
            snprintf(sec, sizeof(sec), "Gun.%s", name);
            snprintf(v, sizeof(v), "%.0f", S.gunRight[t]); WritePrivateProfileStringA(sec, "ShotRight", v, ini);
            snprintf(v, sizeof(v), "%.0f", S.gunUp[t]);    WritePrivateProfileStringA(sec, "ShotUp", v, ini);
            Log("%s bullet nudge: right %.0f, up %.0f degrees (saved)", name, S.gunRight[t], S.gunUp[t]);
            vr_haptic(1, 600);
        }
    }
    if (KeyPressed(VK_F12) && (GetAsyncKeyState(VK_CONTROL) & 0x8000)) {   // Ctrl+F12: mono (smoother recordings)
        S.mono = !S.mono; V.eyeFilled[0] = V.eyeFilled[1] = false; V.pairHas[0] = V.pairHas[1] = false; V.dispValid = false;
        Log("Mono mode %s", S.mono ? "on" : "off");
    }
    if (KeyPressed(VK_F7)) { S.manualReload = !S.manualReload; Log("Manual reload %s", S.manualReload ? "on" : "off"); }
    {   // hand calibration: numpad 8/2 = X, 4/6 = Y, 7/9 = Z  (hold Shift for the left hand)
        int h = (GetAsyncKeyState(VK_SHIFT) & 0x8000) ? 0 : 1;
        const int keys[6] = {VK_NUMPAD8, VK_NUMPAD2, VK_NUMPAD4, VK_NUMPAD6, VK_NUMPAD7, VK_NUMPAD9};
        for (int k = 0; k < 6; k++) if (KeyPressed(keys[k])) {
            S.handRot[h][k / 2] += (k % 2 ? -15.f : 15.f);
            Log("%sHandRot X=%.0f Y=%.0f Z=%.0f", h ? "Right" : "Left", S.handRot[h][0], S.handRot[h][1], S.handRot[h][2]);
        }
    }
}

// ------------------------------------------------------------------------------------------
// VR controllers -> game input
//  * Gameplay: buttons/sticks are merged into the game's own gamepad state (CPad::NewState)
//    right after the game reads its real devices, so keyboard/mouse/gamepad keep working too.
//  * Menus / floating screen: the right controller is a laser pointer that drives the game's
//    menu mouse cursor; trigger = click, stick = navigate, A = select, B = back.
// ------------------------------------------------------------------------------------------
namespace pad {
    constexpr uintptr_t Pad0          = 0xB73458;           // CPad Pads[0]; NewState at +0 (CControllerState)
    constexpr uintptr_t NewMouse      = 0xB73418;           // CMouseControllerState: lmb,rmb,mmb,wheelUp,wheelDown,...
    constexpr uintptr_t MenuMouseWinX = 0xBA6748 + 0xE0;    // FrontEndMenuManager.m_nMousePosWinX
    constexpr uintptr_t MenuMouseWinY = 0xBA6748 + 0xE4;
    constexpr uintptr_t fn_UpdatePads = 0x541DD0;
    constexpr uintptr_t fn_FindPlayerVehicle = 0x56E0D0;    // CVehicle* FindPlayerVehicle(int, bool)
    // CControllerState (shorts)
    enum : int { LX = 0, LY, RX, RY, L1, L2, R1, R2, DUp, DDown, DLeft, DRight, Start, Select,
                 Square, Triangle, Cross, Circle, L3, R3, Count = 24 };
    // call sites of CPad::UpdatePads (E8 call or E9 jmp)
    constexpr uintptr_t sites[] = {0x53BEE6, 0x53E78B, 0x541E50, 0x57C607, 0x57D7C5, 0x731540, 0x748B17};
    constexpr int NSites = sizeof(sites) / sizeof(sites[0]);
}


static struct {
    bool active = false;                           // apply anything this frame
    short st[pad::Count] = {};                     // values to merge into CControllerState
    bool mouseValid = false; int mx = 0, my = 0;   // laser cursor
    bool lmb = false, wheelUp = false, wheelDown = false;
    double menuDownAt = 0; bool menuLong = false;
    uintptr_t prev[pad::NSites] = {};
} In;


static bool LeftHandAtGun();
static bool CtrlAimDirWorld(V3& d);
static short Axis(float v) { v = std::fmax(-1.f, std::fmin(1.f, v)); return (short)(v * 128.f); }
static short Btn(bool b) { return b ? 255 : 0; }
static short Analog(float v) { return (short)(std::fmax(0.f, std::fmin(1.f, v)) * 255.f); }

static void ReadControllers(const float ctrl[2][12], const int ctrlValid[2]) {
    for (int h = 0; h < 2; h++) {
        H[h].prev = H[h].pressed;
        uint64_t touched = 0;
        H[h].valid = vr_controller_state(h, &H[h].pressed, &touched, H[h].ax) != 0;
        H[h].poseValid = ctrlValid[h] != 0;
        if (H[h].poseValid) {
            memcpy(H[h].raw.m, ctrl[h], sizeof(float) * 12);
            // Re-express the controller frame so -Z is the natural pointing direction
            const Pose& r = H[h].raw;
            V3 f = norm(rot(r, S.natFwd[h]));
            V3 u = rot(r, S.natUp[h]);
            u = norm(u - f * dot(u, f));
            V3 rt = cross(f, u);
            Pose& p = H[h].pose;
            p.m[0] = rt.x; p.m[4] = rt.y; p.m[8]  = rt.z;
            p.m[1] = u.x;  p.m[5] = u.y;  p.m[9]  = u.z;
            p.m[2] = -f.x; p.m[6] = -f.y; p.m[10] = -f.z;
            p.m[3] = r.m[3]; p.m[7] = r.m[7]; p.m[11] = r.m[11];
        }
    }
}

static bool InVehicle() {
    return ((void* (__cdecl*)(int, int))pad::fn_FindPlayerVehicle)(-1, 0) != nullptr;
}

// Build this frame's input from the controllers (called once per frame from Present)
static void BuildInput(bool menuMode) {
    g_aimHeld = false;
    In.active = H[0].valid || H[1].valid;
    memset(In.st, 0, sizeof(In.st));
    In.mouseValid = In.lmb = In.wheelUp = In.wheelDown = false;
    if (!In.active) return;
    const Hand& L = H[0];
    const Hand& R = H[1];

    // Left menu button: short press = pause menu (Start), hold 1 s = recenter view
    double now = NowMs();
    if (L.justDown(BTN_MENU)) { In.menuDownAt = now; In.menuLong = false; }
    if (L.down(BTN_MENU) && !In.menuLong && now - In.menuDownAt > 1000) {
        In.menuLong = true; V.needRecenter = true; vr_haptic(0, 3000);
    }
    bool menuTap = !L.down(BTN_MENU) && ((L.prev >> BTN_MENU) & 1) && !In.menuLong;
    static int startFrames = 0;
    if (menuTap) startFrames = 3;                  // hold Start for a few frames so the game sees it
    if (startFrames > 0) { In.st[pad::Start] = 255; startFrames--; }

    if (menuMode) {
        // Laser pointer on the floating screen (right hand, left as fallback)
        for (int h : {1, 0}) {
            float u, v;
            if (H[h].poseValid && vr_overlay_intersect(H[h].pose.m, &u, &v) &&
                u >= 0 && u <= 1 && v >= 0 && v <= 1) {
                In.mouseValid = true;
                In.mx = (int)(u * V.bbW); In.my = (int)(v * V.bbH);
                In.lmb = H[h].trigger() > 0.6f;
                if (In.lmb && (H[h].prev >> BTN_TRIGGER & 1) == 0 && H[h].down(BTN_TRIGGER)) vr_haptic(h, 1500);
                break;
            }
        }
        static int wheelTick = 0;
        float ry = R.sy();
        if (std::fabs(ry) > 0.6f && (wheelTick++ % 4) == 0) { if (ry > 0) In.wheelUp = true; else In.wheelDown = true; }
        // pad-style navigation as well
        float lx = L.sx(), ly = L.sy();
        In.st[pad::DUp] = Btn(ly > 0.6f);   In.st[pad::DDown] = Btn(ly < -0.6f);
        In.st[pad::DLeft] = Btn(lx < -0.6f); In.st[pad::DRight] = Btn(lx > 0.6f);
        In.st[pad::Cross] = Btn(R.down(BTN_A));
        In.st[pad::Triangle] = Btn(R.down(BTN_MENU));
        return;
    }

    if (!InVehicle()) {
        bool holsterGrab = false, leftNearGun = false;
        FootExtras(holsterGrab, leftNearGun);
        if (L.sx() != 0.f) In.st[pad::LX] = Axis(L.sx());
        if (L.sy() != 0.f) In.st[pad::LY] = Axis(-L.sy());
        if (!S.firstPerson) In.st[pad::RX] = Axis(R.sx());   // first person: we turn the body ourselves
        In.st[pad::Circle]   = Btn(R.trigger() > 0.5f);   // fire
        In.st[pad::R1]       = Btn((S.lockOn || !S.motionAim) && L.trigger() > 0.5f);   // aim / lock on
        // Strafing: the game only strafes (faces the camera, walks sideways/backwards with strafe
        // animations) while the aim button is held. Hold it for you whenever the stick points
        // more than ~60 deg away from forward; release near forward so walking/sprinting are normal.
        {
            static bool strafing = false;
            float lx = L.sx(), ly = L.sy(), mag = std::sqrt(lx * lx + ly * ly);
            if (S.strafe && S.firstPerson && mag > 0.3f) {
                float fwd = ly / mag;
                if (!strafing && fwd < 0.5f) strafing = true;
                else if (strafing && fwd > 0.77f) strafing = false;
            } else {
                strafing = false;
            }
            if (strafing) In.st[pad::R1] = 255;
            g_aimHeld = In.st[pad::R1] != 0;
        }
        In.st[pad::Square]   = Btn(R.down(BTN_A));        // jump / climb
        In.st[pad::Triangle] = Btn(R.down(BTN_MENU));     // enter vehicle
        if (L.down(BTN_STICK)) In.st[pad::Cross] = 255;   // sprint (hold left stick click)
        if (R.down(BTN_STICK)) In.st[pad::L3] = 255;      // crouch (also: crouch for real)
        In.st[pad::L2]       = Btn(L.grip() > 0.7f && !LeftHandAtGun() && !leftNearGun);   // previous weapon (not at the gun)
        In.st[pad::R2]       = Btn(R.grip() > 0.7f && !holsterGrab);      // next weapon (unless grabbing a holster)
        In.st[pad::L1]       = Btn(L.down(BTN_A));        // action / talk
    } else {
        // Drive-by: hold the right grip to raise your gun. The game's own drive-by is started for
        // you on the side you point at (look left/right + fire), and the bullets follow your hand.
        // While the grip is held, the right trigger shoots and the left stick also does gas/brake.
        static bool db = false;
        float g = R.grip();
        bool wheel = false, bike = false, wheelOK = false;
        float steer = WheelSteer(wheel, bike, wheelOK);
        bool bothGrips = wheelOK && L.grip() > 0.7f && g > 0.7f;
        if (!db && g > 0.7f && !(wheelOK && L.grip() > 0.5f)) db = true;   // right grip alone = gun up
        else if (db && (g < 0.4f || bothGrips)) db = false;                 // both grips = back on the wheel
        V.driveBy = db && S.driveByByHand;
        In.st[pad::LX] = Axis(L.sx() != 0.f ? L.sx() : (wheel ? steer : 0.f));   // steer: stick, or the wheel
        In.st[pad::RX] = Axis(R.sx());
        In.st[pad::RY] = Axis(-R.sy());
        In.st[pad::R1]       = Btn(R.down(BTN_A));        // handbrake
        In.st[pad::Triangle] = Btn(R.down(BTN_MENU));     // exit vehicle
        In.st[pad::L3]       = Btn(R.down(BTN_STICK));    // horn
        In.st[pad::DUp]      = Btn(L.down(BTN_A));        // next radio station
        if (V.driveBy) {
            float ly = L.sy();
            In.st[pad::Cross]  = Analog(ly);                                             // gas = stick forward
            In.st[pad::Square] = Analog(std::fmax(L.trigger(), -ly));                   // brake = stick back / left trigger
            In.st[pad::Circle] = Btn(R.trigger() > 0.5f);                                // shoot
            // which side are you pointing at? (relative to the vehicle)
            V3 d; bool left = false;
            if (CtrlAimDirWorld(d)) left = dot(d, V.vehRight) < 0;
            if (left) In.st[pad::L2] = 255; else In.st[pad::R2] = 255;            // look left / right
        } else {
            In.st[pad::LY] = Axis(-L.sy());               // lean / pitch
            In.st[pad::Cross]    = Analog(R.trigger());   // accelerate
            In.st[pad::Square]   = Analog(L.trigger());   // brake / reverse
            In.st[pad::Circle]   = Btn(L.down(BTN_STICK));// fire / nitro (left stick click; grips hold the wheel)
        }
    }
    if (!InVehicle()) V.driveBy = false;
}

// Merge into the game's state right after it reads its real devices
static void ApplyInput() {
    if (!In.active) return;
    short* st = &Mem<short>(pad::Pad0);
    for (int i = 0; i < pad::Count; i++) {
        short v = In.st[i];
        if (i <= pad::RY) { if (v != 0) st[i] = v; }      // sticks: override when deflected
        else if (v > st[i]) st[i] = v;                    // buttons: OR (max)
    }
    if (In.mouseValid) {
        Mem<int>(pad::MenuMouseWinX) = In.mx;
        Mem<int>(pad::MenuMouseWinY) = In.my;
        if (In.lmb) Mem<uint8_t>(pad::NewMouse + 0) = 1;
    }
    if (In.wheelUp) Mem<uint8_t>(pad::NewMouse + 3) = 1;
    if (In.wheelDown) Mem<uint8_t>(pad::NewMouse + 4) = 1;
}

template <int N> static void __cdecl hkUpdatePads() {
    ((void (__cdecl*)())In.prev[N])();
    ApplyInput();
}
static void* const g_updatePadsHooks[] = {
    (void*)hkUpdatePads<0>, (void*)hkUpdatePads<1>, (void*)hkUpdatePads<2>, (void*)hkUpdatePads<3>,
    (void*)hkUpdatePads<4>, (void*)hkUpdatePads<5>, (void*)hkUpdatePads<6>};
static_assert(sizeof(g_updatePadsHooks) / sizeof(void*) == pad::NSites, "hook count");

static void PatchInput() {
    for (int i = 0; i < pad::NSites; i++) {
        In.prev[i] = RedirectCall(pad::sites[i], g_updatePadsHooks[i]);
        if (!In.prev[i]) In.prev[i] = pad::fn_UpdatePads;
    }
}


// ------------------------------------------------------------------------------------------
// Motion aiming
//  The player's bullets are traced from the right controller along where it points. We do this
//  inside CWeapon::FireInstantHit: while the PLAYER is firing, the world line-of-sight test that
//  decides what the bullet hits gets its start/end replaced. Tracers, impacts, damage and
//  blood all follow automatically because the game uses those same vectors afterwards.
// ------------------------------------------------------------------------------------------
namespace aim {
    constexpr uintptr_t fn_ProcessLOS   = 0x56BA00;   // CWorld::ProcessLineOfSight
    constexpr uintptr_t pIgnoreEntity   = 0xB7CD68;   // CWorld::pIgnoreEntity
    constexpr uintptr_t fn_RegisterCorona = 0x6FC580; // CCoronas::RegisterCorona (type overload)
    constexpr uintptr_t losSites[]  = {0x73FDC2, 0x740721, 0x740B69, 0x7412B5}; // inside FireInstantHit
    constexpr uintptr_t fireSites[] = {0x742495, 0x7424EC, 0x742548};           // CWeapon::Fire -> FireInstantHit
    constexpr int NLos = 4, NFire = 3;
    constexpr int Ped_Weapons = 0x5A0, Ped_WepSlot = 0x718, Weapon_Size = 0x1C;
}
typedef bool (__cdecl* ProcessLOS_t)(V3*, V3*, void*, void**, int, int, int, int, int, int, int, int);
typedef bool (__thiscall* FireInstantHit_t)(void*, void*, V3*, V3*, void*, V3*, V3*, int, int);
static uintptr_t g_prevLOS[aim::NLos], g_prevFire[aim::NFire];
static bool g_playerFiring = false;

static void* PlayerPed() { return ((void* (__cdecl*)(int))game::fn_FindPlayerPed)(-1); }

static int PlayerWeaponType() {
    uint8_t* ped = (uint8_t*)PlayerPed();
    if (!ped) return 0;
    uint8_t slot = ped[aim::Ped_WepSlot];
    if (slot >= 13) return 0;
    return *(int*)(ped + aim::Ped_Weapons + slot * aim::Weapon_Size);
}
static bool HoldingGun() { int t = PlayerWeaponType(); return t >= 22 && t <= 38; }

static V3 ToWorldDir(V3 v) { return V.wR * v.x + V.wF * (-v.z) + V.wU * v.y; }

// Right-hand aim ray in world space
static bool AimRay(V3& origin, V3& dir) {
    if (!S.motionAim || !V.wValid || !H[1].poseValid || !VRActiveInGame()) return false;
    if (S.handsIK && (V.onFootFP || (V.inVehFP && V.driveBy)) && St.presents - V.gunFrame <= 3) {   // straight out of the gun model
        origin = V.gunPos;
        V3 right = norm(cross(V.gunDir, V.gunUp));
        int t = PlayerWeaponType() & 63;
        dir = norm(V.gunDir + right * std::tan(S.gunRight[t] * 0.0174533f) + V.gunUp * std::tan(S.gunUp[t] * 0.0174533f));
        return true;
    }
    Pose rel = mul(inverseRigid(V.origin), H[1].pose);
    if (!S.positional) {                        // keep hands relative to the (unmoving) view
        Pose head = mul(inverseRigid(V.origin), V.hmd);
        rel.m[3] -= head.m[3]; rel.m[7] -= head.m[7]; rel.m[11] -= head.m[11];
    }
    float p = S.aimPitch * 0.0174533f;
    V3 local{0, std::sin(p), -std::cos(p)};
    V3 d = norm(ToWorldDir(rot(rel, local)));
    origin = V.wBase + ToWorldDir(pos(rel) + V3{0, V.crouchComp, 0}) * S.worldScale + d * 0.10f;
    dir = d;
    return true;
}

static bool CtrlAimDirWorld(V3& d) {
    if (!V.wValid || !H[1].poseValid) return false;
    Pose rel = mul(inverseRigid(V.origin), H[1].pose);
    d = norm(ToWorldDir(rot(rel, V3{0, 0, -1})));
    return true;
}

static bool TraceLOS(V3 a, V3 b, V3& hit) {
    uint8_t colPoint[0x40] = {};
    void* ent = nullptr;
    void*& ignore = Mem<void*>(aim::pIgnoreEntity);
    void* old = ignore;
    ignore = PlayerPed();
    bool r = ((ProcessLOS_t)aim::fn_ProcessLOS)(&a, &b, colPoint, &ent, 1, 1, 1, 1, 0, 0, 0, 1);
    ignore = old;
    if (r) memcpy(&hit, colPoint, sizeof(V3));   // CColPoint::m_vecPoint is first
    return r;
}

static void DrawAimDot();
static void AfterCameraHook() {
    ReloadTick();
    MeleeTick();
    ScopeTick();
    if (S.handsIK && (V.onFootFP || (V.inVehFP && V.driveBy))) return;      // drawn after the arms are posed (BodyEdits)
    DrawAimDot();
}
static void DrawAimDot() {
    if (!S.aimDot || !HoldingGun()) return;
    V3 o, d;
    if (!AimRay(o, d)) return;
    V3 hit;
    if (!TraceLOS(o, o + d * 120.f, hit)) hit = o + d * 60.f;
    float dist = len(hit - o);
    typedef void (__cdecl* Corona_t)(uint32_t, void*, int, int, int, int, const V3*, float, float,
                                     int, int, int, int, int, float, int, float, int, float, int, int);
    ((Corona_t)aim::fn_RegisterCorona)(0x56524152, nullptr, 255, 20, 20, 255, &hit,
        0.03f + dist * 0.006f, 200.f,
        0 /*star*/, 0 /*no flare*/, 0 /*no refl*/, 0 /*no LOS*/, 0 /*no trail*/,
        0.f, 0, 0.f /*don't pull to camera*/, 1 /*full bright*/, 255.f, 0, 0);
    // Laser beam: small dots from the muzzle along the exact bullet line (first 3 m)
    if (S.laser) {
        for (int i = 0; i < 12; i++) {
            float t = 0.02f + i * 0.25f;
            if (t > dist) break;
            V3 p = o + d * t;
            ((Corona_t)aim::fn_RegisterCorona)(0x56524160 + i, nullptr, 255, 30, 30, 200, &p,
                0.012f, 50.f, 0, 0, 0, 0, 0, 0.f, 0, 0.f, 1, 255.f, 0, 0);
        }
    }
}

static void Recoil(int t) {
    if (!S.recoil) return;
    unsigned us = 1500;
    if (t == 25 || t == 26 || t == 27 || t == 35 || t == 36) us = 3999;       // shotguns, rockets
    else if (t == 33 || t == 34) us = 3500;                                    // rifles
    else if (t == 30 || t == 31) us = 2200;                                    // AK / M4
    else if (t == 28 || t == 29 || t == 32) us = 1100;                         // SMGs
    else if (t == 38 || t == 37) us = 600;                                     // minigun / flamer
    vr_haptic(1, (unsigned short)us);
    if (V.twoHand) vr_haptic(0, (unsigned short)(us * 2 / 3));
}

template <int N> static bool __cdecl hkLOS(V3* start, V3* end, void* cp, void** ent,
                                          int b, int v, int p, int o, int d, int st, int ci, int sh) {
    V3 ao, ad;
    if (g_playerFiring && AimRay(ao, ad)) {
        float range = std::fmax(len(*end - *start), 50.f);
        *start = ao;                               // writes the game's own locals: tracer/impact follow
        *end = ao + ad * range;
        void*& ignore = Mem<void*>(aim::pIgnoreEntity);
        void* old = ignore;
        void* veh = ((void* (__cdecl*)(int, int))0x56E0D0)(-1, 0);
        ignore = veh ? veh : PlayerPed();
        bool r = ((ProcessLOS_t)g_prevLOS[N])(start, end, cp, ent, b, v, p, o, d, st, ci, sh);
        ignore = old;
        return r;
    }
    return ((ProcessLOS_t)g_prevLOS[N])(start, end, cp, ent, b, v, p, o, d, st, ci, sh);
}
template <int N> static bool __fastcall hkFireInstantHit(void* weapon, void*, void* firer, V3* origin, V3* muzzle,
                                                        void* target, V3* targetPos, V3* driveBy, int a6, int a7) {
    bool mine = firer && firer == PlayerPed();
    g_playerFiring = mine;
    bool r = ((FireInstantHit_t)g_prevFire[N])(weapon, firer, origin, muzzle, target, targetPos, driveBy, a6, a7);
    g_playerFiring = false;
    if (mine) Recoil(*(int*)weapon);
    return r;
}

// Driver drive-by (old side-window mode): CWeapon::FireInstantHitFromCar -> FireInstantHitFromCar2(start, end, veh, owner)
static uintptr_t g_prevCar2 = 0x73CBA0;
static void __fastcall hkFireFromCar2(void* weapon, void*, V3 start, V3 end, void* veh, void* owner) {
    V3 ao, ad;
    if (V.driveBy && AimRay(ao, ad)) {
        float range = std::fmax(len(end - start), 50.f);
        start = ao; end = ao + ad * range;
    }
    typedef void (__thiscall* F)(void*, V3, V3, void*, void*);
    ((F)g_prevCar2)(weapon, start, end, veh, owner);
    if (V.driveBy) Recoil(*(int*)weapon);
}

static void PatchProjectiles();
static void PatchAim() {
    PatchProjectiles();
    { uintptr_t p = RedirectCall(0x73F3E6, (void*)hkFireFromCar2); if (p) g_prevCar2 = p; }
    void* los[] = {(void*)hkLOS<0>, (void*)hkLOS<1>, (void*)hkLOS<2>, (void*)hkLOS<3>};
    void* fire[] = {(void*)hkFireInstantHit<0>, (void*)hkFireInstantHit<1>, (void*)hkFireInstantHit<2>};
    for (int i = 0; i < aim::NLos; i++) {
        g_prevLOS[i] = RedirectCall(aim::losSites[i], los[i]);
        if (!g_prevLOS[i]) g_prevLOS[i] = aim::fn_ProcessLOS;
    }
    for (int i = 0; i < aim::NFire; i++) {
        g_prevFire[i] = RedirectCall(aim::fireSites[i], fire[i]);
        if (!g_prevFire[i]) g_prevFire[i] = 0x73FB10;
    }
}


// ------------------------------------------------------------------------------------------
// Body: arms follow the controllers (2-bone IK on CJ's skeleton), gun sits in the right hand,
// head hidden in first person. Runs after the game has posed the skeleton for this frame
// (CRenderer::PreRender) and right before the world is drawn, like the game's big-head cheat.
// Bone matrices are world space; the weapon is drawn at the right-hand bone matrix.
// ------------------------------------------------------------------------------------------
struct RwMat { V3 right; uint32_t f0; V3 up; uint32_t f1; V3 at; uint32_t f2; V3 pos; uint32_t f3; };
struct M3 { V3 c[3]; };   // columns
static V3 apply(const M3& m, V3 v) { return m.c[0] * v.x + m.c[1] * v.y + m.c[2] * v.z; }
static M3 rotFromTo(V3 a, V3 b) {
    a = norm(a); b = norm(b);
    V3 ax = cross(a, b);
    float sn = len(ax), cs = dot(a, b);
    if (sn < 1e-5f) return M3{{{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}};
    ax = ax * (1.f / sn);
    float t = 1 - cs, x = ax.x, y = ax.y, z = ax.z;
    return M3{{{t * x * x + cs, t * x * y + sn * z, t * x * z - sn * y},
               {t * x * y - sn * z, t * y * y + cs, t * y * z + sn * x},
               {t * x * z + sn * y, t * y * z - sn * x, t * z * z + cs}}};
}
static void rotateBone(RwMat& m, const M3& R, V3 pivot) {
    m.right = apply(R, m.right); m.up = apply(R, m.up); m.at = apply(R, m.at);
    m.pos = pivot + apply(R, m.pos - pivot);
}
static int BoneIndex(uint8_t* hier, int id) {
    int n = *(int*)(hier + 4);
    uint8_t* info = *(uint8_t**)(hier + 0x10);
    if (!info) return -1;
    for (int i = 0; i < n; i++) if (*(int*)(info + i * 16) == id) return *(int*)(info + i * 16 + 4);
    return -1;
}
static M3 EulerDeg(const float r[3]) {
    float x = r[0] * 0.0174533f, y = r[1] * 0.0174533f, z = r[2] * 0.0174533f;
    M3 X{{{1, 0, 0}, {0, std::cos(x), std::sin(x)}, {0, -std::sin(x), std::cos(x)}}};
    M3 Y{{{std::cos(y), 0, -std::sin(y)}, {0, 1, 0}, {std::sin(y), 0, std::cos(y)}}};
    M3 Z{{{std::cos(z), std::sin(z), 0}, {-std::sin(z), std::cos(z), 0}, {0, 0, 1}}};
    auto mm = [](const M3& a, const M3& b) { return M3{{apply(a, b.c[0]), apply(a, b.c[1]), apply(a, b.c[2])}}; };
    return mm(mm(X, Y), Z);
}

// Controller pose -> world (position + axes)
static bool CtrlWorld(int h, V3& p, V3 ax[3]) {
    if (!V.wValid || !H[h].poseValid) return false;
    Pose rel = mul(inverseRigid(V.origin), H[h].pose);
    if (!S.positional) {
        Pose head = mul(inverseRigid(V.origin), V.hmd);
        rel.m[3] -= head.m[3]; rel.m[7] -= head.m[7]; rel.m[11] -= head.m[11];
    }
    V3 off{S.handOff[0] * (h ? 1.f : -1.f), S.handOff[1], S.handOff[2]};
    p = V.wBase + ToWorldDir(pos(rel) + rot(rel, off) + V3{0, V.crouchComp, 0}) * S.worldScale;
    for (int i = 0; i < 3; i++) ax[i] = norm(ToWorldDir(col(rel, i)));
    return true;
}

// Express a world vector in a bone's local frame and back
static V3 toLocal(const RwMat& m, V3 v) { return {dot(v, norm(m.right)), dot(v, norm(m.up)), dot(v, norm(m.at))}; }
static V3 toWorld(const RwMat& m, V3 v) { return norm(m.right) * v.x + norm(m.up) * v.y + norm(m.at) * v.z; }
static M3 axisAngle(V3 k, float ang) {
    float c = std::cos(ang), s2 = std::sin(ang), t = 1 - c;
    return M3{{{t * k.x * k.x + c, t * k.x * k.y + s2 * k.z, t * k.x * k.z - s2 * k.y},
               {t * k.x * k.y - s2 * k.z, t * k.y * k.y + c, t * k.y * k.z + s2 * k.x},
               {t * k.x * k.z + s2 * k.y, t * k.y * k.z - s2 * k.x, t * k.z * k.z + c}}};
}
// Signed angle (about unit axis) that turns `from` onto `to`, both projected onto the plane of the axis
static float twistAngle(V3 axis, V3 from, V3 to) {
    V3 f = from - axis * dot(from, axis), t = to - axis * dot(to, axis);
    if (len(f) < 1e-4f || len(t) < 1e-4f) return 0;
    f = norm(f); t = norm(t);
    return std::atan2(dot(axis, cross(f, t)), dot(f, t));
}
// Roll a bone's orientation about an axis (position unchanged)
static void rollBone(RwMat& m, V3 axis, float ang) {
    M3 R = axisAngle(axis, ang);
    m.right = apply(R, m.right); m.up = apply(R, m.up); m.at = apply(R, m.at);
}

static void ArmIK(RwMat* mats, uint8_t* hier, int h) {
    const int base = h ? 22 : 32;                       // upper arm, fore arm, hand, finger, finger01
    int idx[5];
    for (int i = 0; i < 5; i++) if ((idx[i] = BoneIndex(hier, base + i)) < 0) return;
    V3 T, cax[3];
    if (!CtrlWorld(h, T, cax)) return;

    // --- Reference relations from the game's own animated arm (anatomically sensible) ---
    bool haveHinge = false;
    V3 hingeInUpper{}, hingeInFore{}, handYInFore{};
    {
        const RwMat& U0 = mats[idx[0]]; const RwMat& F0 = mats[idx[1]]; const RwMat& H0 = mats[idx[2]];
        V3 u = norm(F0.pos - U0.pos), f = norm(H0.pos - F0.pos);
        V3 hinge = cross(u, f);
        if (len(hinge) > 0.05f) {          // elbow bent enough in the animation to read its hinge
            hinge = norm(hinge);
            hingeInUpper = toLocal(U0, hinge);
            hingeInFore = toLocal(F0, hinge);
            haveHinge = true;
        }
        handYInFore = toLocal(F0, norm(H0.up));
    }

    // Shoulder assist: swing the clavicle (and everything below it) a fraction of the way toward
    // the target so the sleeve/shoulder skin doesn't tear when reaching far.
    int clav = BoneIndex(hier, h ? 21 : 31);
    if (clav >= 0 && S.shoulderAssist > 0) {
        V3 piv = mats[clav].pos;
        V3 a = mats[idx[2]].pos - piv, b = T - piv;
        M3 full = rotFromTo(a, b);
        // scale the rotation angle
        V3 ax = cross(norm(a), norm(b));
        float sn = len(ax), cs = dot(norm(a), norm(b));
        if (sn > 1e-4f) {
            float ang = std::atan2(sn, cs) * S.shoulderAssist;
            V3 k = ax * (1.f / sn);
            float c = std::cos(ang), s2 = std::sin(ang), t = 1 - c;
            M3 Rp{{{t * k.x * k.x + c, t * k.x * k.y + s2 * k.z, t * k.x * k.z - s2 * k.y},
                   {t * k.x * k.y - s2 * k.z, t * k.y * k.y + c, t * k.y * k.z + s2 * k.x},
                   {t * k.x * k.z + s2 * k.y, t * k.y * k.z - s2 * k.x, t * k.z * k.z + c}}};
            rotateBone(mats[clav], Rp, piv);
            for (int i = 0; i < 5; i++) rotateBone(mats[idx[i]], Rp, piv);
        }
        (void)full;
    }
    RwMat& up = mats[idx[0]]; RwMat& fo = mats[idx[1]]; RwMat& ha = mats[idx[2]];
    V3 S0 = up.pos, E = fo.pos, W = ha.pos;
    float L1 = len(E - S0), L2 = len(W - E);
    if (L1 < 0.05f || L2 < 0.05f) return;
    V3 toT = T - S0;
    float d = std::fmax(std::fabs(L1 - L2) + 0.01f, std::fmin(L1 + L2 - 0.005f, len(toT)));
    V3 dir = norm(toT);
    T = S0 + dir * d;
    // elbow points down and a bit outward
    V3 side = norm(cross(V.wF, V.wU)) * (h ? 1.f : -1.f);
    V3 pole = V3{0, 0, -1} + side * 0.5f - V.wF * 0.2f;
    pole = norm(pole - dir * dot(pole, dir));
    float a = (d * d + L1 * L1 - L2 * L2) / (2 * d);
    float hh = std::sqrt(std::fmax(0.f, L1 * L1 - a * a));
    V3 E2 = S0 + dir * a + pole * hh;

    M3 R1 = rotFromTo(E - S0, E2 - S0);
    for (int i = 0; i < 5; i++) rotateBone(mats[idx[i]], R1, S0);
    M3 R2 = rotFromTo(mats[idx[2]].pos - E2, T - E2);
    for (int i = 1; i < 5; i++) rotateBone(mats[idx[i]], R2, E2);

    // Hand orientation from the controller (with calibration), fingers follow
    // Hand bone axes expressed in controller space.
    // The weapon is drawn in the right-hand bone's space with the barrel along +X and the grip
    // along +Y (gun top = -Y). The game draws a second pistol in the LEFT hand by rotating the
    // left-hand matrix 180 deg about X, so for the left hand the gun top is +Y.
    // Controller space: forward = -Z, up = +Y, right = +X.
    static const V3 K[2][3] = {
        {{0, 0, -1}, {0, 1, 0}, {1, 0, 0}},               // left:  X=fwd, Y=up,   Z=X*Y
        {{0, 0, -1}, {0, -1, 0}, {-1, 0, 0}}};            // right: X=fwd, Y=down, Z=X*Y
    float rotDeg[3] = {S.handRot[h][0] + (h ? S.aimPitch : 0.f), S.handRot[h][1], S.handRot[h][2]};
    M3 cal = EulerDeg(rotDeg);
    M3 cw{{cax[0], cax[1], cax[2]}};                       // controller axes (world)
    V3 newAx[3];
    for (int i = 0; i < 3; i++) newAx[i] = norm(apply(cw, apply(cal, K[h][i])));
    // rotation taking the current hand axes to the new ones, applied to hand + fingers about the wrist
    RwMat& hand = mats[idx[2]];
    M3 cur{{norm(hand.right), norm(hand.up), norm(hand.at)}};
    // R = New * Cur^T
    M3 R;
    for (int c = 0; c < 3; c++) {
        V3 e{c == 0 ? 1.f : 0.f, c == 1 ? 1.f : 0.f, c == 2 ? 1.f : 0.f};
        V3 inCur{dot(cur.c[0], e), dot(cur.c[1], e), dot(cur.c[2], e)};   // Cur^T * e
        R.c[c] = newAx[0] * inCur.x + newAx[1] * inCur.y + newAx[2] * inCur.z;
    }
    for (int i = 2; i < 5; i++) rotateBone(mats[idx[i]], R, hand.pos);

    // --- Twist correction: keep the elbow hinge and the wrist anatomically plausible ---
    {
        RwMat& U = mats[idx[0]]; RwMat& F = mats[idx[1]]; RwMat& Hd = mats[idx[2]];
        V3 uAx = norm(F.pos - U.pos), fAx = norm(Hd.pos - F.pos);
        V3 n = cross(uAx, fAx);                       // the plane the IK bent the arm in
        if (len(n) > 0.02f && haveHinge) {
            n = norm(n);
            rollBone(U, uAx, twistAngle(uAx, toWorld(U, hingeInUpper), n));
            rollBone(F, fAx, twistAngle(fAx, toWorld(F, hingeInFore), n));
        }
        // Wrist: how far is the hand rolled relative to where the forearm "expects" it?
        float wrist = twistAngle(fAx, toWorld(F, handYInFore), norm(Hd.up));
        rollBone(F, fAx, wrist * S.forearmTwist);     // forearm takes part of it, wrist keeps the rest
    }

    if (h == 1) {   // remember where the drawn gun points: bullets and the red dot use this
        V3 barrel = norm(hand.right);
        V3 muzzle = hand.pos + barrel * S.barrelFwd + norm(hand.up) * -S.barrelUp;   // fallback
        // Exact muzzle: the weapon's own fire offset (weapon.dat), in right-hand bone space -
        // the same point the game uses for the muzzle flash and its own bullets.
        int type = PlayerWeaponType();
        if (type >= 22 && type <= 38) {
            uint8_t* ped = (uint8_t*)PlayerPed();
            int skill = ped ? (int)((uint8_t (__thiscall*)(void*))0x5E6580)(ped) : 1;   // CPed::GetWeaponSkill
            uint8_t* wi = ((uint8_t* (__cdecl*)(int, int))0x743C60)(type, skill);       // CWeaponInfo::GetWeaponInfo
            if (wi) {
                V3 fo = *(V3*)(wi + 0x24);                                                // m_vecFireOffset
                muzzle = hand.pos + hand.right * fo.x + hand.up * fo.y + hand.at * fo.z;
                static int loggedType = -1;
                if (loggedType != type) {
                    loggedType = type;
                    V3 camF = V.wF;
                    Log("Gun %d skill %d: fireOffset (%.2f %.2f %.2f) | hand axis lengths %.3f %.3f %.3f | "
                        "barrel.fwd %.2f barrel.up %.2f | handZ.up %.2f handY.up %.2f | muzzle-hand %.3f m",
                        type, skill, fo.x, fo.y, fo.z, len(hand.right), len(hand.up), len(hand.at),
                        dot(barrel, camF), barrel.z, norm(hand.at).z, norm(hand.up).z, len(muzzle - hand.pos));
                }
            }
        }
        V.gunPos = muzzle;
        V.gunDir = barrel;
        V.gunUp = norm(hand.at);
        V.gunFrame = St.presents;
    }
}

static void BodyEdits() {
    static int lastFrame = -1;
    int frame = St.presents;
    if (frame == lastFrame) return;
    lastFrame = frame;
    if (!V.wValid || !S.firstPerson || Mem<uint8_t>(game::Cam_WideScreenOn)) return;
    uint8_t* ped = (uint8_t*)PlayerPed();
    if (!ped) return;
    void* clump = *(void**)(ped + 0x18);
    if (!clump) return;
    uint8_t* hier = ((uint8_t* (__cdecl*)(void*))0x734A40)(clump);   // GetAnimHierarchyFromSkinClump
    if (!hier) return;
    RwMat* mats = *(RwMat**)(hier + 8);
    if (!mats) return;

    if (S.hideHead) {
        // Shrink the head into the NECK joint (not to a point under your eyes), so neck/collar
        // skin that is partly attached to the head doesn't get stretched up into the view.
        int neck = BoneIndex(hier, 4);
        for (int id : {5, 6, 7, 8}) {                    // head, brows, jaw
            int i = BoneIndex(hier, id);
            if (i < 0) continue;
            mats[i].right = mats[i].right * 0.001f;
            mats[i].up = mats[i].up * 0.001f;
            mats[i].at = mats[i].at * 0.001f;
            if (neck >= 0) mats[i].pos = mats[neck].pos;
        }
    }
    static bool dumped = false;
    if (!dumped) {   // one-time skeleton dump for troubleshooting
        dumped = true;
        int n = *(int*)(hier + 4);
        uint8_t* info = *(uint8_t**)(hier + 0x10);
        char line[1024]; int o = snprintf(line, sizeof(line), "Skeleton %d bones:", n);
        for (int i = 0; i < n && info && o < 1000; i++) o += snprintf(line + o, sizeof(line) - o, " %d", *(int*)(info + i * 16));
        Log("%s", line);
    }
    if (S.handsIK && V.onFootFP) {
        ArmIK(mats, hier, 1);
        ArmIK(mats, hier, 0);
        DrawAimDot();                            // same frame as the gun is drawn: dot sits on the barrel line
    } else if (S.handsIK && V.inVehFP && V.driveBy) {
        ArmIK(mats, hier, 1);                    // gun hand follows your controller; left hand stays on the wheel
        DrawAimDot();
    }
}

// ------------------------------------------------------------------------------------------
// Manual reloading: an empty gun stays empty (no automatic reload) until you bring your left
// hand to the gun and squeeze the left grip. You can also top up early the same way.
// F7 or ManualReload=0 switches back to the game's automatic reloading.
// ------------------------------------------------------------------------------------------
static bool ManualReloadWeapon(int t) {
    return (t >= 22 && t <= 32 && t != 25);   // pistols, sawn-off, SPAS, SMGs, AK, M4 (not the pump shotgun)
}
static bool LeftHandAtGun() {
    if (!H[0].poseValid || !H[1].poseValid || !HoldingGun()) return false;
    V3 a = pos(H[0].pose), b = pos(H[1].pose);
    return len(a - b) < 0.25f;
}

// ------------------------------------------------------------------------------------------
// Swing melee: punch / hit with a melee weapon by actually swinging the controller.
// Tracks the world-space tip of each hand (fist, or end of the bat/knife/...), and when it moves
// fast enough through a ped, damages them through the game's own CWeapon::GenerateDamageEvent
// (hit reaction anims, knock-downs, crime reports, peds fighting back all work as normal).
static bool IsMeleeType(int t) { return t >= 0 && t <= 15; }
static float MeleeReach(int t) {        // metres from the fist to the useful end of the weapon
    switch (t) {
    case 2: case 3: case 5: case 6: case 7: case 15: return 0.85f;   // golf club, nightstick, bat, shovel, cue, cane
    case 8: return 0.95f;                                            // katana
    case 4: return 0.22f;                                            // knife
    case 9: return 0.55f;                                            // chainsaw
    case 10: case 11: case 12: case 13: case 14: return 0.30f;       // dildos/vibrator/flowers
    default: return 0.f;                                             // fist / knuckles
    }
}
static float MeleeBase(int t) {
    switch (t) {
    case 0: return 6.f; case 1: return 11.f; case 4: return 30.f; case 8: return 55.f; case 9: return 80.f;
    case 10: case 11: case 12: case 13: case 14: return 5.f;
    default: return 17.f;
    }
}
static V3 EntPos(uint8_t* e) {
    uint8_t* m = *(uint8_t**)(e + 0x14);
    return m ? *(V3*)(m + 0x30) : *(V3*)(e + 4);
}
static void MeleeTick() {
    static V3 prevTip[2]; static bool prevOk[2] = {};
    static double prevT = 0; static double cool[2] = {};
    static void* lastVictim[2] = {}; static double lastVictimT[2] = {};
    double now = NowMs();
    double dt = (now - prevT) * 0.001; prevT = now;
    uint8_t* me = (uint8_t*)PlayerPed();
    if (!S.swingMelee || !me || !V.onFootFP || !V.wValid || !VRActiveInGame() || dt <= 0 || dt > 0.1) {
        prevOk[0] = prevOk[1] = false; return;
    }
    int wt = PlayerWeaponType();
    for (int h = 0; h < 2; h++) {
        if (!H[h].poseValid) { prevOk[h] = false; continue; }
        int t = (h == 1) ? wt : 0;                      // left hand is always a fist
        if (h == 1 && !IsMeleeType(t)) { prevOk[h] = false; continue; }   // holding a gun: no punching with it
        if (h == 0 && !IsMeleeType(wt) && g_aimHeld) { prevOk[h] = false; continue; }   // left hand steadying an aimed gun
        Pose rel = mul(inverseRigid(V.origin), H[h].pose);
        V3 hand = V.wBase + ToWorldDir(pos(rel) + V3{0, V.crouchComp, 0}) * S.worldScale;
        V3 fwd = norm(ToWorldDir(rot(rel, V3{0, 0, -1})));
        float reach = MeleeReach(t);
        V3 tip = hand + fwd * reach;
        if (!prevOk[h]) { prevTip[h] = tip; prevOk[h] = true; continue; }
        float speed = len(tip - prevTip[h]) / (float)dt / S.worldScale;   // real m/s
        V3 tipPrev = prevTip[h];
        prevTip[h] = tip;
        if (speed < S.swingSpeed || now < cool[h]) continue;

        // Pool walk: CPools::ms_pPedPool
        uint8_t* pool = *(uint8_t**)0xB74490;
        if (!pool) continue;
        uint8_t* objs = *(uint8_t**)pool; uint8_t* flags = *(uint8_t**)(pool + 4); int n = *(int*)(pool + 8);
        uint8_t* best = nullptr; float bestD = 1e9f; V3 bestP{};
        for (int i = 0; i < n; i++) {
            if (flags[i] & 0x80) continue;
            uint8_t* p = objs + i * 0x7C4;
            if (p == me) continue;
            if (*(float*)(p + 0x540) <= 0.f) continue;              // health
            int st = *(int*)(p + 0x530);                             // ped state
            if (st == 50 || st == 54 || st == 55) continue;          // driving / die / dead
            V3 c = EntPos(p);
            // sample along the weapon (fist..tip) and along the swing (prev tip..tip)
            for (int k = 0; k <= 4; k++) {
                float a = k / 4.f;
                V3 q = (k < 3) ? hand + (tip - hand) * (a * 1.5f > 1.f ? 1.f : a * 1.5f) : tipPrev + (tip - tipPrev) * (k == 3 ? 0.5f : 1.f);
                float dz = q.z - c.z;
                if (dz < -1.0f || dz > 0.85f) continue;              // ped is roughly pos.z-1 .. +0.8
                float dx = q.x - c.x, dy = q.y - c.y;
                float d = std::sqrt(dx * dx + dy * dy);
                float r = dz > 0.45f ? 0.25f : 0.42f;                // head is thinner than the body
                if (d < r && d < bestD) { bestD = d; best = p; bestP = q; }
            }
        }
        if (!best) continue;
        if (best == lastVictim[h] && now - lastVictimT[h] < 450) continue;
        lastVictim[h] = best; lastVictimT[h] = now;
        cool[h] = now + 250;

        V3 c = EntPos(best);
        int piece = (bestP.z - c.z > 0.45f) ? 9 /*head*/ : 3 /*torso*/;
        // direction the hit comes from, relative to the victim: 0 front, 1 left, 2 back, 3 right
        uint8_t* m = *(uint8_t**)(best + 0x14);
        int dir = 0;
        if (m) {
            V3 vr = *(V3*)(m + 0x0), vf = *(V3*)(m + 0x10);
            V3 from = EntPos(me) - c;
            float df = dot(from, vf), dr = dot(from, vr);
            if (std::fabs(df) >= std::fabs(dr)) dir = df >= 0 ? 0 : 2; else dir = dr >= 0 ? 3 : 1;
        }
        float scale = std::fmin(speed / S.swingSpeed, 2.5f);
        int dmg = (int)(MeleeBase(t) * scale * S.meleeDamage + 0.5f);
        if (piece == 9) dmg = dmg * 3 / 2;
        typedef bool (__cdecl* Dmg_t)(void*, void*, int, int, int, uint8_t);
        ((Dmg_t)0x73A530)(best, me, t, dmg, piece, (uint8_t)dir);
        vr_haptic(h, (unsigned short)std::fmin(1200.f + speed * 600.f, 3999.f));
        Log("Swing hit: hand %d weapon %d speed %.1f m/s dmg %d piece %d", h, t, speed, dmg, piece);
    }
}

// ------------------------------------------------------------------------------------------
// Hand motion: position/velocity of each controller in VR space (relative to the recenter origin)
// ------------------------------------------------------------------------------------------
static V3 g_velHist[2][8]; static double g_velT[2][8]; static int g_velI[2];
static void UpdateHandMotion() {
    static double tPrev = 0;
    double now = NowMs(), dt = (now - tPrev) * 0.001; tPrev = now;
    for (int h = 0; h < 2; h++) {
        if (!H[h].poseValid) { V.hmv[h] = false; continue; }
        V3 p = pos(mul(inverseRigid(V.origin), H[h].pose));
        if (V.hmv[h] && dt > 0.002 && dt < 0.1) {
            V3 v = (p - V.handRel[h]) * (float)(1.0 / dt);
            V.handVel[h] = V.handVel[h] * 0.4f + v * 0.6f;
        } else V.handVel[h] = {0, 0, 0};
        V.handRel[h] = p; V.hmv[h] = true;
        int i = g_velI[h]++ & 7;
        g_velHist[h][i] = V.handVel[h]; g_velT[h][i] = now;
    }
}

// ------------------------------------------------------------------------------------------
// Two-handed long guns: squeeze the left grip with your left hand out in front of the right hand
// and the gun aims along the line from your right hand to your left hand (steady, like a real rifle).
// ------------------------------------------------------------------------------------------
static bool IsTwoHandedGun(int t) { return t == 25 || t == 27 || t == 29 || t == 30 || t == 31 || (t >= 33 && t <= 38); }
static void TwoHandTick() {
    bool want = false;
    if (S.twoHanded && S.handsIK && V.onFootFP && H[0].poseValid && H[1].poseValid && IsTwoHandedGun(PlayerWeaponType())) {
        V3 r = pos(H[1].pose), l = pos(H[0].pose), d = l - r;
        float dist = len(d);
        V3 fwd = col(H[1].pose, 2) * -1.0f;
        if (V.twoHand) want = H[0].grip() > 0.5f && dist > 0.12f && dist < 0.9f;
        else want = H[0].justDown(BTN_GRIP) && dist > 0.25f && dist < 0.75f && dot(norm(d), fwd) > 0.5f;
    }
    if (want && !V.twoHand) { vr_haptic(0, 1500); }
    V.twoHand = want;
    if (!want) return;
    V3 fwd = col(H[1].pose, 2) * -1.0f;
    V3 d = norm(pos(H[0].pose) - pos(H[1].pose));
    M3 R = rotFromTo(fwd, d);
    Pose& p = H[1].pose;
    for (int c = 0; c < 3; c++) {
        V3 v = apply(R, V3{p.m[c], p.m[4 + c], p.m[8 + c]});
        p.m[c] = v.x; p.m[4 + c] = v.y; p.m[8 + c] = v.z;
    }
}

// ------------------------------------------------------------------------------------------
// Scope: bring the sniper rifle / camera up to your eye and the view zooms in (right stick
// up/down changes the zoom). Move it away to zoom back out.
// ------------------------------------------------------------------------------------------
static void ScopeTick() {
    bool want = false;
    int t = PlayerWeaponType();
    if (V.onFootFP && (t == 34 || t == 43) && H[1].poseValid && V.hmdValid && S.scopeZoom > 1.01f) {
        V3 muzzleish = pos(H[1].pose);
        float d = len(muzzleish - pos(V.hmd));
        want = V.scoped ? d < 0.30f : d < 0.20f;
    }
    if (want && !V.scoped) { V.zoom = S.scopeZoom; vr_haptic(1, 800); }
    if (want) {
        float ry = H[1].sy();
        V.zoom = std::fmax(1.5f, std::fmin(12.f, V.zoom * (1.f + ry * 0.03f)));
    }
    V.scoped = want;
}

// ------------------------------------------------------------------------------------------
// Swimming, real crouch, holsters (on-foot input extras; called from BuildInput)
// ------------------------------------------------------------------------------------------
static bool IsSwimming() {
    uint8_t* ped = (uint8_t*)PlayerPed();
    if (!ped) return false;
    void* intel = *(void**)(ped + 0x47C);
    return intel && ((void* (__thiscall*)(void*))0x601070)(intel) != nullptr;   // CPedIntelligence::GetTaskSwim
}
enum { Z_NONE = -1, Z_RSHOULDER, Z_LSHOULDER, Z_RHIP, Z_LHIP, Z_CHEST, Z_LCHEST };
static int HolsterZone() {
    if (!H[1].poseValid || !V.hmdValid) return Z_NONE;
    V3 head = pos(V.hmd);
    V3 f = col(V.hmd, 2) * -1.0f; f.y = 0;
    if (len(f) < 0.1f) return Z_NONE;
    f = norm(f);
    V3 r = cross(f, V3{0, 1, 0});
    V3 d = pos(H[1].pose) - head;
    float x = dot(d, r), y = d.y, z = dot(d, f);
    if (y > -0.25f && z < 0.05f && std::fabs(x) < 0.40f) return x >= 0 ? Z_RSHOULDER : Z_LSHOULDER;   // over a shoulder
    if (y < -0.45f && y > -1.2f && std::fabs(x) > 0.08f && z < 0.25f) return x > 0 ? Z_RHIP : Z_LHIP;  // at a hip
    if (y <= -0.20f && y >= -0.45f && z > -0.05f && z < 0.35f && std::fabs(x) < 0.28f)
        return x < -0.06f ? Z_LCHEST : Z_CHEST;                                                         // chest
    return Z_NONE;
}
static void HolsterGrab(int zone) {
    static const int lists[6][3] = {{5, 3, -1}, {6, 7, -1}, {2, -1, -1}, {1, 9, -1}, {4, -1, -1}, {8, 10, 12}};
    uint8_t* ped = (uint8_t*)PlayerPed();
    if (!ped) return;
    uint8_t* pd = *(uint8_t**)(ped + 0x480);                 // CPlayerData
    if (!pd) return;
    int cur = ped[aim::Ped_WepSlot];
    auto has = [&](int sl) {
        uint8_t* w = ped + aim::Ped_Weapons + sl * aim::Weapon_Size;
        return *(int*)w != 0 && (sl == 1 || sl == 10 || sl == 12 || *(int*)(w + 0xC) > 0);
    };
    const int* L = lists[zone];
    int n = 0; while (n < 3 && L[n] >= 0) n++;
    int at = -1;
    for (int i = 0; i < n; i++) if (L[i] == cur) at = i;
    int pick = -1;
    for (int k = 1; k <= n; k++) {
        int i = (at + k + n) % n;
        if (at < 0) i = k - 1;
        if (L[i] != cur && has(L[i])) { pick = L[i]; break; }
    }
    if (pick < 0 && at >= 0) pick = 0;                       // grabbed the holster of what you hold: put it away
    if (pick < 0) { vr_haptic(1, 300); return; }             // nothing there
    pd[0x20] = (uint8_t)pick;                                // m_nChosenWeapon: the game switches (with its own checks)
    vr_haptic(1, 1800);
    Log("Holster zone %d -> slot %d", zone, pick);
}
static void FootExtras(bool& holsterGrab, bool& leftNearGun) {
    const Hand& L = H[0]; const Hand& R = H[1];
    double now = NowMs();
    // left hand near the gun: left grip is reload / two-hand hold, never "previous weapon"
    leftNearGun = V.twoHand || (HoldingGun() && H[0].poseValid && H[1].poseValid && len(pos(H[0].pose) - pos(H[1].pose)) < 0.75f);

    // Holsters: right grip pressed in a body zone picks that zone's weapon
    static bool grabbing = false;
    if (R.grip() < 0.4f) grabbing = false;
    if (S.holsters && R.justDown(BTN_GRIP) && VRActiveInGame()) {
        int z = HolsterZone();
        if (z != Z_NONE) { grabbing = true; HolsterGrab(z); }
    }
    holsterGrab = grabbing;

    bool swimming = IsSwimming();
    // Swimming: pull both hands back (breaststroke) to swim forward; hard strokes swim fast
    if (S.swimStrokes && swimming && V.hmv[0] && V.hmv[1] && V.hmdValid) {
        V3 f = col(mul(inverseRigid(V.origin), V.hmd), 2) * -1.0f; f.y = 0;
        if (len(f) > 0.1f) {
            f = norm(f);
            float v0 = dot(V.handVel[0], f), v1 = dot(V.handVel[1], f);
            static double strokeUntil = 0, fastUntil = 0, lastStroke = 0;
            if (v0 < -0.8f && v1 < -0.8f && now - lastStroke > 350) {
                lastStroke = now;
                strokeUntil = now + 900;
                if (v0 + v1 < -3.5f) fastUntil = now + 120;
                vr_haptic(0, 600); vr_haptic(1, 600);
            }
            if (now < strokeUntil && L.sx() == 0.f && L.sy() == 0.f) In.st[pad::LY] = Axis(-1.f);
            if (now < fastUntil) In.st[pad::Cross] = 255;
        }
    }

    // Real crouch: your head drops -> CJ crouches; stand up -> he stands
    if (S.realCrouch && S.positional && V.hmdValid && VRActiveInGame()) {
        float y = pos(mul(inverseRigid(V.origin), V.hmd)).y;
        if (!V.standValid) { V.standY = y; V.standValid = true; }
        if (y > V.standY) V.standY = y;
        float drop = V.standY - y;
        static bool want = false, prevWant = false, target = false;
        static double enforceUntil = 0, lastPress = 0;
        if (!want && drop > S.crouchDepth) want = true;
        else if (want && drop < S.crouchDepth - 0.10f) want = false;
        if (want != prevWant) { target = want; enforceUntil = now + 1500; }
        prevWant = want;
        uint8_t* ped = (uint8_t*)PlayerPed();
        bool ducked = ped && (ped[0x46F] & 4);
        if (now < enforceUntil && !swimming) {
            if (ducked == target) enforceUntil = 0;
            else if (now - lastPress > 400) { In.st[pad::L3] = 255; lastPress = now; }
        }
    }
}

// ------------------------------------------------------------------------------------------
// Steering wheel / handlebars: hold both grips. Cars/boats: turn the wheel (tilt the line between
// your hands). Bikes/quads: push one hand forward and pull the other back, like handlebars.
// ------------------------------------------------------------------------------------------
static float WheelSteer(bool& wheel, bool& bike, bool& wheelOK) {
    uint8_t* veh = (uint8_t*)((void* (__cdecl*)(int, int))0x56E0D0)(-1, 0);
    int sub = veh ? *(int*)(veh + 0x594) : -1;
    bike = sub == 2 || sub == 9 || sub == 10;
    wheelOK = S.wheelSteering && (sub == 0 || sub == 1 || sub == 5 || bike);
    wheel = wheelOK && H[0].grip() > 0.7f && H[1].grip() > 0.7f && V.hmv[0] && V.hmv[1];
    if (!wheel) return 0.f;
    V3 v = V.handRel[1] - V.handRel[0];
    float ang = bike ? std::atan2(v.z, v.x) : std::atan2(-v.y, v.x);
    float st = ang / (std::fmax(10.f, S.wheelMaxAngle) * 0.0174533f);
    return std::fmax(-1.f, std::fmin(1.f, st));
}

// ------------------------------------------------------------------------------------------
// Throwing by hand: release the trigger at the end of a real throw; the grenade/molotov/teargas/
// satchel leaves your hand with your hand's velocity. Rockets launch from the launcher, along it.
// ------------------------------------------------------------------------------------------
static V3 g_throwVel{}; static double g_throwT = -1e9;
static bool IsThrowType(int t) { return t == 16 || t == 17 || t == 18 || t == 39; }
static void ThrowTick() {
    static bool held = false;
    bool h = H[1].trigger() > 0.5f;
    if (held && !h && IsThrowType(PlayerWeaponType())) {
        double now = NowMs(); float best = 0; V3 bv{};
        for (int i = 0; i < 8; i++) {
            if (now - g_velT[1][i] > 160) continue;
            float sp = len(g_velHist[1][i]);
            if (sp > best) { best = sp; bv = g_velHist[1][i]; }
        }
        g_throwVel = bv; g_throwT = now;
        Log("Throw released: %.1f m/s", best);
    }
    held = h;
}
static uintptr_t g_prevAddProj = 0x737C80;
static bool __cdecl hkAddProjectile(void* creator, int type, V3 posn, float force, V3* dir, void* victim) {
    uint8_t act[32];
    for (int i = 0; i < 32; i++) act[i] = Mem<uint8_t>(0xC891A8 + i * 0x24 + 0x10);   // gaProjectileInfo[i].m_bActive
    typedef bool (__cdecl* F)(void*, int, V3, float, V3*, void*);
    bool r = ((F)g_prevAddProj)(creator, type, posn, force, dir, victim);
    if (!r || !creator || creator != PlayerPed() || !VRActiveInGame()) return r;
    int slot = -1;
    for (int i = 0; i < 32; i++) if (!act[i] && Mem<uint8_t>(0xC891A8 + i * 0x24 + 0x10)) { slot = i; break; }
    if (slot < 0) return r;
    uint8_t* obj = Mem<uint8_t*>(0xC89110 + slot * 4);                                // ms_apProjectile[i]
    float* m = obj ? *(float**)(obj + 0x14) : nullptr;
    if (!m) return r;
    V3& vel = *(V3*)(obj + 0x44);                                                       // m_vecMoveSpeed
    V3 np{}, nv{}; bool set = false; bool orient = false; V3 ad{};
    V3 ao;
    if ((type == 19 || type == 20) && AimRay(ao, ad)) {                                 // rockets
        float sp = std::fmax(len(vel), 0.3f);
        np = ao + ad * 0.4f; nv = ad * sp; set = orient = true;
        Recoil(35);
    } else if (IsThrowType(type) && S.throwByHand && NowMs() - g_throwT < 2500) {
        float sp = len(g_throwVel);
        V3 hp, ax[3];
        if (sp > 1.0f && CtrlWorld(1, hp, ax)) {
            V3 wd = norm(ToWorldDir(g_throwVel));
            np = hp + wd * 0.15f;
            nv = wd * (sp * S.worldScale * S.throwStrength / 50.f);                     // per 1/50 s step
            set = true;
        }
        g_throwT = -1e9;
    }
    if (set) {
        m[12] = np.x; m[13] = np.y; m[14] = np.z;
        vel = nv;
        Mem<V3>(0xC891A8 + slot * 0x24 + 0x14) = np;                                    // m_vecLastPosn
        if (orient) {
            V3 rt = cross(ad, V3{0, 0, 1});
            rt = len(rt) < 0.01f ? V3{1, 0, 0} : norm(rt);
            V3 upv = cross(rt, ad);
            m[0] = rt.x; m[1] = rt.y; m[2] = rt.z;
            m[4] = ad.x; m[5] = ad.y; m[6] = ad.z;
            m[8] = upv.x; m[9] = upv.y; m[10] = upv.z;
        }
        Log("Projectile %d set by hand: speed %.2f", type, len(nv));
    }
    return r;
}
static void PatchProjectiles() {
    uintptr_t p = RedirectCall(0x741A53, (void*)hkAddProjectile);   // CWeapon::FireProjectile -> CProjectileInfo::AddProjectile
    if (p) g_prevAddProj = p;
}

static void ReloadTick() {
    // Empty guns are parked in WEAPONSTATE_OUT_OF_AMMO (3): firing is blocked and the game plays
    // nothing. (Parking them in RELOADING made the game loop CJ's reload animation forever.)
    // The reload gesture refills the magazine ourselves after ReloadTimeMs.
    static bool pending = false, heldByUs = false;
    static int pendingType = 0;
    static uint32_t doneAt = 0;
    uint8_t* ped = (uint8_t*)PlayerPed();
    if (!ped) return;
    uint8_t slot = ped[aim::Ped_WepSlot];
    if (slot >= 13) return;
    uint8_t* w = ped + aim::Ped_Weapons + slot * aim::Weapon_Size;
    int type = *(int*)w; int& state = *(int*)(w + 4);
    int clip = *(int*)(w + 8), total = *(int*)(w + 0xC);
    uint32_t now = Mem<uint32_t>(0xB7CB84);                // CTimer::m_snTimeInMilliseconds
    auto refill = [&] { ((void (__thiscall*)(void*, void*))0x73AEB0)(w, ped); };   // CWeapon::Reload

    if (!VRActiveInGame()) return;                         // menus etc: leave everything as is
    bool manual = S.manualReload && ManualReloadWeapon(type);
    if (!manual) {
        // switching back to automatic (or a weapon we don't manage): release anything we parked
        if (heldByUs && state == 3 && total > 0) { refill(); state = 0; }
        heldByUs = false; pending = false;
        return;
    }
    if (pending && type != pendingType) pending = false;     // switched weapons mid-reload

    if (pending) {
        state = 3;
        if ((int32_t)(now - doneAt) >= 0) {
            refill();
            state = 0;                                          // WEAPONSTATE_READY
            pending = false; heldByUs = false;
            vr_haptic(1, 1200);
        }
        return;
    }
    // reload gesture: left hand at the gun + squeeze left grip (also tops up a partial magazine)
    if (H[0].justDown(BTN_GRIP) && LeftHandAtGun() && total > clip && state != 1) {
        pending = true; pendingType = type;
        doneAt = now + (uint32_t)S.reloadMs;
        state = 3; heldByUs = true;
        vr_haptic(0, 2500);
        return;
    }
    // empty: park it so the game never refills it on its own
    if (clip == 0 && total > 0 && (state == 0 || state == 2)) { state = 3; heldByUs = true; }
    if (state == 3 && clip == 0 && H[1].justDown(BTN_TRIGGER)) vr_haptic(1, 800);   // dry-fire click
}



// ------------------------------------------------------------------------------------------
// Full stereo: after the game has drawn the LEFT eye (scene + CJ's weapon + effects), copy the
// visible part of it aside, move the camera to the RIGHT eye and draw scene/weapons/effects a
// second time. Both eyes are then fresh every frame from the same head pose (no alternating,
// no pair delay). The visible lens areas of both eyes are packed side by side into one target,
// so the GPU->CPU copy is ~25% smaller than a full frame.
// ------------------------------------------------------------------------------------------
static IDirect3DSurface9* g_stereoRT = nullptr;
static IDirect3DSurface9* g_stereoSys = nullptr;
static ID3D11Texture2D* g_stereoTex = nullptr;
static RECT g_eyeRect[2];
static int g_cropW = 0, g_cropH = 0;
static bool g_leftCaptured = false, g_rightRendered = false, g_deferWeaponClear = false;
static int g_rwArgs[7];
// Per-frame effect lists the game empties right after drawing them (count reset to 0, data kept).
// Saved before the left eye is drawn and restored before the right-eye pass, or the right eye
// loses headlight/taillight glows, traffic lights, shiny glints and ground shadows/light pools.
static uint32_t g_saveBrightLights, g_saveShinyTexts;
static uint16_t g_saveShadows;
// Light pools on the ground/floors (street lamps, interior lamps, windows) are "static shadows".
// RenderScene runs CShadows::UpdateStaticShadows, which deletes every one not refreshed since the
// last call and clears the "just refreshed" flag. Lamps refresh once per frame, so the right-eye
// pass would delete them all. Save the flags before the left eye, restore before the right eye.
static uint8_t g_saveShadowFresh[48];
static bool g_inRightPass = false;
static uintptr_t g_prevUpdStatic = 0x707F40;
// CShadows::UpdateStaticShadows (called inside RenderScene): skip it during the right-eye pass,
// so the light pools the left eye just drew are still there for the right eye.
static void __cdecl hkUpdateStaticShadows() {
    if (g_inRightPass) return;
    ((void (__cdecl*)())g_prevUpdStatic)();
}
static int CountStaticShadows() {
    int n = 0;
    for (int i = 0; i < 48; i++) if (Mem<uint32_t>(0xC4A030 + i * 0x40 + 4)) n++;
    return n;
}
static uintptr_t g_prevDoRW = 0x53D7A0, g_prevWeaponClear = 0x53E8D0;

// Save a top-down 32-bit BMP of what both eyes get (left half = left eye, right half = right eye)
static void SaveEyesBmp(const uint8_t* bits, int pitch, int w, int h) {
    static int n = 0;
    char path[MAX_PATH];
    snprintf(path, sizeof(path), "%sGTASA_VR_eyes_%03d.bmp", g_dir, ++n);
    FILE* f = fopen(path, "wb");
    if (!f) { Log("! could not write %s", path); return; }
    uint32_t imgSize = (uint32_t)(w * 4 * h);
    uint8_t hdr[54] = {'B', 'M'};
    *(uint32_t*)(hdr + 2) = 54 + imgSize;
    *(uint32_t*)(hdr + 10) = 54;
    *(uint32_t*)(hdr + 14) = 40;
    *(int32_t*)(hdr + 18) = w;
    *(int32_t*)(hdr + 22) = -h;           // top-down
    *(uint16_t*)(hdr + 26) = 1;
    *(uint16_t*)(hdr + 28) = 32;
    *(uint32_t*)(hdr + 34) = imgSize;
    fwrite(hdr, 1, 54, f);
    for (int y = 0; y < h; y++) fwrite(bits + y * pitch, 1, w * 4, f);
    fclose(f);
    Log("Saved eye screenshot %s (%dx%d)", path, w, h);
}

static void ReleaseStereo9() {
    if (g_stereoRT) { g_stereoRT->Release(); g_stereoRT = nullptr; }
    if (g_stereoSys) { g_stereoSys->Release(); g_stereoSys = nullptr; }
}
static bool EnsureStereo(IDirect3DDevice9* dev) {
    for (int e = 0; e < 2; e++) {
        const EyeInfo& E = V.eye[e];
        g_eyeRect[e].left = (LONG)(E.u0 * V.bbW);
        g_eyeRect[e].top = (LONG)(E.v0 * V.bbH);
        g_eyeRect[e].bottom = (LONG)std::ceil(E.v1 * V.bbH);
        g_eyeRect[e].right = (LONG)std::ceil(E.u1 * V.bbW);
    }
    int w = std::min(g_eyeRect[0].right - g_eyeRect[0].left, g_eyeRect[1].right - g_eyeRect[1].left);
    int h = std::min(g_eyeRect[0].bottom - g_eyeRect[0].top, g_eyeRect[1].bottom - g_eyeRect[1].top);
    for (int e = 0; e < 2; e++) { g_eyeRect[e].right = g_eyeRect[e].left + w; g_eyeRect[e].bottom = g_eyeRect[e].top + h; }
    if (w <= 0 || h <= 0) return false;
    if (g_stereoRT && (w != g_cropW || h != g_cropH)) {
        ReleaseStereo9();
        if (g_stereoTex) { g_stereoTex->Release(); g_stereoTex = nullptr; }
    }
    g_cropW = w; g_cropH = h;
    if (!g_stereoRT && FAILED(dev->CreateRenderTarget(2 * w, h, D3DFMT_X8R8G8B8, D3DMULTISAMPLE_NONE, 0, FALSE, &g_stereoRT, nullptr))) return false;
    if (!g_stereoSys && FAILED(dev->CreateOffscreenPlainSurface(2 * w, h, D3DFMT_X8R8G8B8, D3DPOOL_SYSTEMMEM, &g_stereoSys, nullptr))) return false;
    if (!g_stereoTex) {
        D3D11_TEXTURE2D_DESC d{};
        d.Width = 2 * w; d.Height = h; d.MipLevels = 1; d.ArraySize = 1;
        d.Format = DXGI_FORMAT_B8G8R8A8_UNORM; d.SampleDesc.Count = 1;
        d.Usage = D3D11_USAGE_DEFAULT; d.BindFlags = D3D11_BIND_SHADER_RESOURCE;
        if (FAILED(g_d11->CreateTexture2D(&d, nullptr, &g_stereoTex))) return false;
    }
    return true;
}
// copy one eye's visible area from the back buffer into its half of the stereo target (GPU only)
static bool CopyEye(IDirect3DDevice9* dev, int e) {
    IDirect3DSurface9* bb = nullptr;
    if (FAILED(dev->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &bb))) return false;
    D3DSURFACE_DESC d;
    bb->GetDesc(&d);
    static bool logged = false;
    if (!logged) { logged = true; Log("Back buffer multisample type %d quality %lu", (int)d.MultiSampleType, d.MultiSampleQuality); }
    // Resolve the WHOLE frame first (partial-rectangle copies out of an anti-aliased back buffer
    // give broken edges on many drivers), then cut this eye's lens area out of the resolved copy.
    HRESULT hr = E_FAIL;
    if (g_rt || SUCCEEDED(dev->CreateRenderTarget(d.Width, d.Height, D3DFMT_X8R8G8B8, D3DMULTISAMPLE_NONE, 0, FALSE, &g_rt, nullptr))) {
        if (SUCCEEDED(dev->StretchRect(bb, nullptr, g_rt, nullptr, D3DTEXF_NONE))) {
            RECT dst{e * g_cropW, 0, e * g_cropW + g_cropW, g_cropH};
            hr = dev->StretchRect(g_rt, &g_eyeRect[e], g_stereoRT, &dst, D3DTEXF_NONE);
        }
    }
    bb->Release();
    return SUCCEEDED(hr);
}


// GPU -> CPU -> SteamVR for the packed stereo frame (both eyes side by side)
static bool g_pendingSubmit = false;
static Pose g_pendingPose{};
static void ReadbackAndSubmit(IDirect3DDevice9* dev) {
    g_pendingSubmit = false;
    if (!g_stereoRT || !g_stereoSys || !g_stereoTex) return;
    double t = NowMs();
    D3DLOCKED_RECT lr;
    if (SUCCEEDED(dev->GetRenderTargetData(g_stereoRT, g_stereoSys)) &&
        SUCCEEDED(g_stereoSys->LockRect(&lr, nullptr, 0))) {
            for (int y = 0; y < g_cropH; y++) {
                uint32_t* row = (uint32_t*)((uint8_t*)lr.pBits + y * lr.Pitch);
                for (int x = 0; x < 2 * g_cropW; x++) row[x] |= 0xFF000000u;
            }
            if (g_shotRequested) { g_shotRequested = false; SaveEyesBmp((const uint8_t*)lr.pBits, lr.Pitch, 2 * g_cropW, g_cropH); }
            g_ctx->UpdateSubresource(g_stereoTex, 0, nullptr, lr.pBits, lr.Pitch, 0);
            g_stereoSys->UnlockRect();
            St.capMs += NowMs() - t;
            St.cap[0]++; St.cap[1]++;
            V.dispPose = g_pendingPose;
            for (int e = 0; e < 2; e++)
                vr_submit(e, g_stereoTex, e ? 0.5f : 0.f, 0.f, e ? 1.f : 0.5f, 1.f, V.dispPose.m);
        }
    g_ctx->Flush();
}

// 3D markers (mission cylinders, arrows over peds/cars, user markers, direction arrows) are
// "consumed" when drawn: the draw clears their in-use flags, and a marker found unused there has
// its model deleted. Without this the right-eye pass deleted every marker's model, and the game
// (which only rebuilds the model for brand-new markers) then drew nothing in either eye.
static uint8_t g_saveMarkerFlags[32][2], g_saveArrowUsed[5], g_saveUserUsed[5];
static void SaveMarkers() {
    for (int i = 0; i < 32; i++) { g_saveMarkerFlags[i][0] = Mem<uint8_t>(0xC7DD58 + i * 0xA0 + 0x52); g_saveMarkerFlags[i][1] = Mem<uint8_t>(0xC7DD58 + i * 0xA0 + 0x53); }
    for (int i = 0; i < 5; i++) { g_saveArrowUsed[i] = Mem<uint8_t>(0xC802E8 + i * 0x30); g_saveUserUsed[i] = Mem<uint8_t>(0xC80258 + i * 0x1C); }
}
static void RestoreMarkers() {
    for (int i = 0; i < 32; i++) { Mem<uint8_t>(0xC7DD58 + i * 0xA0 + 0x52) = g_saveMarkerFlags[i][0]; Mem<uint8_t>(0xC7DD58 + i * 0xA0 + 0x53) = g_saveMarkerFlags[i][1]; }
    for (int i = 0; i < 5; i++) { Mem<uint8_t>(0xC802E8 + i * 0x30) = g_saveArrowUsed[i]; Mem<uint8_t>(0xC80258 + i * 0x1C) = g_saveUserUsed[i]; }
}

static bool __cdecl hkDoRW(int a, int b, int c, int d, int e, int f, int g) {
    if (g_pendingSubmit) {
        IDirect3DDevice9* dev = Mem<IDirect3DDevice9*>(game::D3DDevicePtr);
        if (dev) ReadbackAndSubmit(dev);
    }
    g_rwArgs[0] = a; g_rwArgs[1] = b; g_rwArgs[2] = c; g_rwArgs[3] = d; g_rwArgs[4] = e; g_rwArgs[5] = f; g_rwArgs[6] = g;
    g_leftCaptured = g_rightRendered = false;
    g_deferWeaponClear = V.full && V.rValid && VRActiveInGame();
    if (g_deferWeaponClear) {
        g_saveBrightLights = Mem<uint32_t>(0xC7C6FC);     // CBrightLights::NumBrightLights
        g_saveShinyTexts   = Mem<uint32_t>(0xC7C6F8);     // CShinyTexts::NumShinyTexts
        g_saveShadows      = Mem<uint16_t>(0xC403DC);     // CShadows::ShadowsStoredToBeRendered
        SaveMarkers();
        for (int i = 0; i < 48; i++) g_saveShadowFresh[i] = Mem<uint8_t>(0xC4A030 + i * 0x40 + 0x3A);   // aStaticShadows[i].m_bJustCreated
    }
    return ((bool (__cdecl*)(int, int, int, int, int, int, int))g_prevDoRW)(a, b, c, d, e, f, g);
}
static void __fastcall hkWeaponClear(void* list, void*) {
    if (g_deferWeaponClear) return;           // keep the list: the right-eye pass draws the weapons again
    ((void (__thiscall*)(void*))g_prevWeaponClear)(list);
}

// Diagnostics: how many glow sprites (coronas: street lamps, traffic lights, car lights) are
// active and on screen according to the game's view matrix right now.
static void CountCoronas(int& active, int& onScreen, float vm0[3]) {
    active = onScreen = 0;
    const float* M = &Mem<float>(game::TheCamera + 0xA04);     // TheCamera.m_mViewMatrix
    vm0[0] = M[12]; vm0[1] = M[13]; vm0[2] = M[14];
    for (int i = 0; i < 64; i++) {
        uint8_t* c = (uint8_t*)0xC3E058 + i * 0x3C;              // CCoronas::aCoronas[i]
        if (!*(uint32_t*)(c + 0xC)) continue;
        if (!c[0x30] && !c[0x2C + 3]) continue;
        active++;
        V3 p = *(V3*)c;
        float x = M[0] * p.x + M[4] * p.y + M[8] * p.z + M[12];
        float y = M[1] * p.x + M[5] * p.y + M[9] * p.z + M[13];
        float z = M[2] * p.x + M[6] * p.y + M[10] * p.z + M[14];
        if (z > 1.f && x / z >= 0 && x / z <= 1 && y / z >= 0 && y / z <= 1) onScreen++;
    }
}

static void RenderRightEye() {
    if (!g_deferWeaponClear) return;
    g_deferWeaponClear = false;
    IDirect3DDevice9* dev = Mem<IDirect3DDevice9*>(game::D3DDevicePtr);
    void* cam = Mem<void*>(game::Scene_RwCamera);
    bool ok = dev && cam && EnsureStereo(dev) && CopyEye(dev, 0);
    if (ok) {
        g_leftCaptured = true;
        // camera -> right eye
        memcpy(&Mem<float>(game::Cam_Matrix), V.rMat, sizeof(V.rMat));
        ((void (__thiscall*)(void*, int))0x50AFA0)((void*)game::TheCamera, 1);          // CopyCameraMatrixToRWCam
        ((void (__thiscall*)(void*, int, int))game::fn_CalcDerived)((void*)game::TheCamera, 0, 1);
        ((void* (__cdecl*)(void*))0x7EE180)(cam);                                       // RwCameraEndUpdate
        int* a = g_rwArgs;
        int aL, sL, aR, sR; float vL[3], vR[3];
        CountCoronas(aL, sL, vL);
        if (((bool (__cdecl*)(int, int, int, int, int, int, int))g_prevDoRW)(a[0], a[1], a[2], a[3], a[4], a[5], a[6])) {
            // make sure the game's own copy of the view matrix (used to place glow sprites) is the right eye's
            memcpy(&Mem<float>(game::TheCamera + 0xA04), (uint8_t*)cam + 0x20, 64);
            CountCoronas(aR, sR, vR);
            static DWORD lastLog = 0;
            if (GetTickCount() - lastLog > 5000) {
                lastLog = GetTickCount();
                int ids = 0, firstId = 0; uint8_t fade = 0, alpha = 0;
                for (int i = 0; i < 64; i++) {
                    uint8_t* c = (uint8_t*)0xC3E058 + i * 0x3C;
                    if (*(uint32_t*)(c + 0xC)) { if (!ids) { firstId = *(int*)(c + 0xC); fade = c[0x30]; alpha = c[0x2F]; } ids++; }
                }
                Log("coronas: L active %d on-screen %d | R active %d on-screen %d | slots used %d (first id %08X fade %d alpha %d) | "
                    "brightlights %u shiny %u shadows %u | hour %d",
                    aL, sL, aR, sR, ids, firstId, fade, alpha, g_saveBrightLights, g_saveShinyTexts, g_saveShadows,
                    (int)Mem<uint8_t>(0xB70153));
            }
            ((void (__cdecl*)())0x734650)();                                               // DefinedState
            ((void* (__cdecl*)(void*, float))0x7EE2A0)(cam, Mem<float>(0xB7C4F0));         // far clip
            *(float*)((uint8_t*)cam + 0x88) = Mem<float>(0xB7C4F4);                        // fog plane
            ((void (__cdecl*)())0x726090)();                                               // CMirrors::RenderMirrorBuffer (floor/wall reflections)
            Mem<uint32_t>(0xC7C6FC) = g_saveBrightLights;
            Mem<uint32_t>(0xC7C6F8) = g_saveShinyTexts;
            Mem<uint16_t>(0xC403DC) = g_saveShadows;
            RestoreMarkers();
            for (int i = 0; i < 48; i++)
                if (Mem<uint32_t>(0xC4A030 + i * 0x40 + 4))                                 // still has its geometry
                    Mem<uint8_t>(0xC4A030 + i * 0x40 + 0x3A) = g_saveShadowFresh[i];
            int shadowsBefore = CountStaticShadows();
            g_inRightPass = true;
            ((void (__cdecl*)())0x53DF40)();                                               // RenderScene
            g_inRightPass = false;
            static DWORD lastShLog = 0;
            if (GetTickCount() - lastShLog > 5000) {
                lastShLog = GetTickCount();
                Log("light pools: %d before right eye, %d after", shadowsBefore, CountStaticShadows());
            }
            ((void (__cdecl*)())0x732F30)();                                               // RenderWeaponPedsForPC
            ((void (__thiscall*)(void*))g_prevWeaponClear)((void*)0xC88224);               // ResetWeaponPedsForPC
            ((void (__cdecl*)())0x53E170)();                                               // RenderEffects
            g_rightRendered = true;
            return;
        }
    }
    ((void (__thiscall*)(void*))g_prevWeaponClear)((void*)0xC88224);
}

// ------------------------------------------------------------------------------------------
// HUD panel: the game's 2D layer (HUD, radar, subtitles, help text, fades) is redirected into a
// transparent render target instead of being painted over the 3D view, then shown on a
// head-locked SteamVR panel. Fixes the radar/corners being cut off by the lenses and the HUD
// sitting "at infinity" in both eyes.
// ------------------------------------------------------------------------------------------
static IDirect3DSurface9* g_hudRT = nullptr;
static IDirect3DSurface9* g_hudSys = nullptr;
static IDirect3DSurface9* g_savedRT = nullptr;
static ID3D11Texture2D* g_hudTex = nullptr;
static bool g_hudCapturing = false, g_hudFresh = false, g_hudShown = false;
static DWORD g_hudSaved[4];
static uintptr_t g_prevRender2d = 0x53E230, g_prevCamEnd = 0x7EE180;

static void ReleaseHud9() {
    if (g_hudRT) { g_hudRT->Release(); g_hudRT = nullptr; }
    if (g_hudSys) { g_hudSys->Release(); g_hudSys = nullptr; }
}
static void BeginHud() {
    IDirect3DDevice9* dev = Mem<IDirect3DDevice9*>(game::D3DDevicePtr);
    if (!dev || V.bbW <= 0) return;
    if (!g_hudRT && FAILED(dev->CreateRenderTarget(V.bbW, V.bbH, D3DFMT_A8R8G8B8, D3DMULTISAMPLE_NONE, 0, FALSE, &g_hudRT, nullptr))) return;
    if (FAILED(dev->GetRenderTarget(0, &g_savedRT))) return;
    dev->SetRenderTarget(0, g_hudRT);
    dev->Clear(0, nullptr, D3DCLEAR_TARGET, 0x00000000, 1.0f, 0);
    // proper coverage in the alpha channel (colour ends up premultiplied)
    dev->GetRenderState(D3DRS_SEPARATEALPHABLENDENABLE, &g_hudSaved[0]);
    dev->GetRenderState(D3DRS_SRCBLENDALPHA, &g_hudSaved[1]);
    dev->GetRenderState(D3DRS_DESTBLENDALPHA, &g_hudSaved[2]);
    dev->GetRenderState(D3DRS_BLENDOPALPHA, &g_hudSaved[3]);
    dev->SetRenderState(D3DRS_SEPARATEALPHABLENDENABLE, TRUE);
    dev->SetRenderState(D3DRS_SRCBLENDALPHA, D3DBLEND_ONE);
    dev->SetRenderState(D3DRS_DESTBLENDALPHA, D3DBLEND_INVSRCALPHA);
    dev->SetRenderState(D3DRS_BLENDOPALPHA, D3DBLENDOP_ADD);
    g_hudCapturing = true;
}
static void EndHud() {
    if (!g_hudCapturing) return;
    IDirect3DDevice9* dev = Mem<IDirect3DDevice9*>(game::D3DDevicePtr);
    dev->SetRenderState(D3DRS_SEPARATEALPHABLENDENABLE, g_hudSaved[0]);
    dev->SetRenderState(D3DRS_SRCBLENDALPHA, g_hudSaved[1]);
    dev->SetRenderState(D3DRS_DESTBLENDALPHA, g_hudSaved[2]);
    dev->SetRenderState(D3DRS_BLENDOPALPHA, g_hudSaved[3]);
    dev->SetRenderTarget(0, g_savedRT);
    g_savedRT->Release(); g_savedRT = nullptr;
    g_hudCapturing = false;
    g_hudFresh = true;
}
static uintptr_t g_prevCrossHairs = 0x58E020;
static void __cdecl hkCrossHairs() {
    if (S.hideCrosshair && VRActiveInGame()) return;
    ((void (__cdecl*)())g_prevCrossHairs)();
}
static void __cdecl hkRender2d() {
    RenderRightEye();
    if (S.hudPanel && VRActiveInGame()) BeginHud();
    ((void (__cdecl*)())g_prevRender2d)();
}
static void* __cdecl hkCamEndUpdate(void* cam) {
    EndHud();
    return ((void* (__cdecl*)(void*))g_prevCamEnd)(cam);
}
// Called from Present: copy the HUD layer to SteamVR every few frames
static void UpdateHudPanel(IDirect3DDevice9* dev, bool inGameVR) {
    if (!S.hudPanel || !inGameVR || !g_hudRT) {
        if (g_hudShown) { vr_hud_show(nullptr, 0); g_hudShown = false; }
        return;
    }
    static int n = 0;
    if (!g_hudFresh || (n++ % 3) != 0) return;
    g_hudFresh = false;
    static int hudW = 0, hudH = 0;
    if (g_hudTex && (hudW != V.bbW || hudH != V.bbH)) {      // resolution changed
        g_hudTex->Release(); g_hudTex = nullptr;
        if (g_hudSys) { g_hudSys->Release(); g_hudSys = nullptr; }
    }
    D3DSURFACE_DESC rd;
    if (FAILED(g_hudRT->GetDesc(&rd)) || (int)rd.Width != V.bbW || (int)rd.Height != V.bbH) { ReleaseHud9(); return; }
    if (!g_hudTex) {
        hudW = V.bbW; hudH = V.bbH;
        D3D11_TEXTURE2D_DESC d{};
        d.Width = V.bbW; d.Height = V.bbH; d.MipLevels = 1; d.ArraySize = 1;
        d.Format = DXGI_FORMAT_B8G8R8A8_UNORM; d.SampleDesc.Count = 1;
        d.Usage = D3D11_USAGE_DEFAULT; d.BindFlags = D3D11_BIND_SHADER_RESOURCE;
        if (FAILED(g_d11->CreateTexture2D(&d, nullptr, &g_hudTex))) return;
        vr_hud_create(S.hudWidth);
        vr_hud_place(S.hudDistance, S.hudDown);
    }
    if (!g_hudSys && FAILED(dev->CreateOffscreenPlainSurface(V.bbW, V.bbH, D3DFMT_A8R8G8B8, D3DPOOL_SYSTEMMEM, &g_hudSys, nullptr))) return;
    if (FAILED(dev->GetRenderTargetData(g_hudRT, g_hudSys))) return;
    D3DLOCKED_RECT lr;
    if (FAILED(g_hudSys->LockRect(&lr, nullptr, D3DLOCK_READONLY))) return;
    g_ctx->UpdateSubresource(g_hudTex, 0, nullptr, lr.pBits, lr.Pitch, 0);
    g_hudSys->UnlockRect();
    vr_hud_show(g_hudTex, 1);
    g_hudShown = true;
}

// ------------------------------------------------------------------------------------------
// Present / Reset hooks
// ------------------------------------------------------------------------------------------
typedef HRESULT (STDMETHODCALLTYPE* Present_t)(IDirect3DDevice9*, const RECT*, const RECT*, HWND, const RGNDATA*);
typedef HRESULT (STDMETHODCALLTYPE* Reset_t)(IDirect3DDevice9*, D3DPRESENT_PARAMETERS*);
static Present_t oPresent;
static Reset_t oReset;
static bool g_gamePatched = false;
static bool g_inputPatched = false;

static void PatchGameCode() {
    g_prevCalcDerived = RedirectCall(game::site_ProcessCalcDerived, (void*)hkCalcDerived);
    g_prevCameraSizeA = RedirectCall(game::site_CameraSize_A, (void*)hkCameraSizeA);
    g_prevCameraSizeB = RedirectCall(game::site_CameraSize_B, (void*)hkCameraSizeB);
    if (!g_prevCalcDerived) g_prevCalcDerived = game::fn_CalcDerived;
    if (!g_prevCameraSizeA) g_prevCameraSizeA = game::fn_CameraSize;
    if (!g_prevCameraSizeB) g_prevCameraSizeB = game::fn_CameraSize;
    PatchAim();
    Log("Control method: %s", Mem<uint8_t>(0xBA6748 + 0xD0) ? "joypad (aim button = lock-on)" : "mouse+keyboard (aim button = free aim)");
    if (uintptr_t p = RedirectCall(0x53EB12, (void*)hkRender2d)) g_prevRender2d = p;      // Idle: Render2dStuff
    if (uintptr_t p = RedirectCall(0x58FBBF, (void*)hkCrossHairs)) g_prevCrossHairs = p;  // CHud::Draw: DrawCrossHairs
    if (uintptr_t p = RedirectCall(0x53E0BE, (void*)hkUpdateStaticShadows)) g_prevUpdStatic = p;  // RenderScene: UpdateStaticShadows
    if (uintptr_t p = RedirectCall(0x53EA7E, (void*)hkDoRW)) g_prevDoRW = p;              // Idle: DoRWStuffStartOfFrame_Horizon
    if (uintptr_t p = RedirectCall(0x53EACE, (void*)hkWeaponClear)) g_prevWeaponClear = p; // Idle: ResetWeaponPedsForPC
    if (uintptr_t p = RedirectCall(0x53EBF5, (void*)hkCamEndUpdate)) g_prevCamEnd = p;    // Idle: RwCameraEndUpdate
    g_gamePatched = true;
}

static void VRFrame(IDirect3DDevice9* dev) {
    static int frames = 0;
    bool trace = frames++ < 2;
    if (trace) Log("frame %d: start", frames);
    PollKeys();
    CalibrationTick();
    if (!EnsureResources(dev)) return;

    if (g_pendingSubmit) ReadbackAndSubmit(dev);         // last frame wasn't picked up at render start
    bool inGameVR = V.frameHasCam && VRActiveInGame();
    if (inGameVR && V.full && g_leftCaptured && g_rightRendered) {
        if (CopyEye(dev, 1)) {
            g_pendingSubmit = true;
            g_pendingPose = V.framePose;
            // Pipelined: read it back when the next frame starts rendering (the GPU has finished it
            // by then, so the CPU doesn't sit waiting). Otherwise read it back right now.
            if (!S.pipelined) ReadbackAndSubmit(dev);
        }
        g_leftCaptured = g_rightRendered = false;
        UpdateHudPanel(dev, inGameVR);
        if (V.overlayShown) { vr_overlay_show(nullptr, 0); V.overlayShown = false; }
        g_ctx->Flush();
        V.frameHasCam = false;
        return;
    }
    if (inGameVR) {
        bool monoLike = S.mono || V.full;      // full-stereo pass failed this frame: show it mono
        int e = monoLike ? 0 : V.frameEye;
        bool legacy = !S.paired && !monoLike;
        ID3D11Texture2D* target = legacy ? g_dispTex[e] : g_eyeTex[e];
        double t = NowMs();
        if (CaptureBackBuffer(dev, target)) {
            St.capMs += NowMs() - t;
            St.cap[e]++;
            if (monoLike) {
                std::swap(g_eyeTex[0], g_dispTex[0]);
                V.dispPose = V.framePose; V.dispValid = true; V.dispMono = true;
            } else {
                if (St.lastCapEye == e) St.sameEyeTwice++;
                St.lastCapEye = e;
                V.nextEye = S.swapEyes ? e : 1 - e;   // next frame renders the other eye
                if (legacy) {
                    V.eyeFilled[e] = true;
                    V.lastPose[e] = V.framePose;
                } else {
                    V.pairHas[e] = true;
                    if (V.pairHas[0] && V.pairHas[1]) {  // pair complete -> publish
                        std::swap(g_eyeTex[0], g_dispTex[0]);
                        std::swap(g_eyeTex[1], g_dispTex[1]);
                        V.dispPose = V.framePose; V.dispValid = true; V.dispMono = false;
                        V.pairHas[0] = V.pairHas[1] = false;
                    }
                }
            }
        }
    } else if (VRActiveInGame()) {
        St.noCam++;
    }
    // Submit both eyes every frame
    for (int e = 0; e < 2; e++) {
        const EyeInfo& E = V.eye[e];
        if (S.paired || S.mono || V.full) {
            if (!V.dispValid) continue;
            vr_submit(e, g_dispTex[V.dispMono ? 0 : e], E.u0, E.v0, E.u1, E.v1, V.dispPose.m);
        } else {
            int src = V.eyeFilled[e] ? e : (V.eyeFilled[1 - e] ? 1 - e : -1);
            if (src < 0) continue;
            vr_submit(e, g_dispTex[src], E.u0, E.v0, E.u1, E.v1, V.lastPose[src].m);
        }
    }

    UpdateHudPanel(dev, inGameVR);

    // Virtual screen for menus / loading / flat mode
    bool wantScreen = !inGameVR;
    if (wantScreen) {
        if (CaptureBackBuffer(dev, g_screenTex)) {
            if ((!V.overlayShown || V.placeScreen) && V.hmdValid) { vr_overlay_place(V.hmd.m, S.screenDistance); V.placeScreen = false; }
            vr_overlay_show(g_screenTex, 1);
            V.overlayShown = true;
        }
    } else if (V.overlayShown) {
        vr_overlay_show(nullptr, 0);
        V.overlayShown = false;
    }
    g_ctx->Flush();
    V.frameHasCam = false;
    if (trace) Log("frame %d: submitted (screen=%d)", frames, (int)wantScreen);
}

static HRESULT STDMETHODCALLTYPE hkPresent(IDirect3DDevice9* dev, const RECT* a, const RECT* b, HWND w, const RGNDATA* r) {
    static double lastPresent = 0;
    double tp = NowMs();
    if (lastPresent > 0) St.frameMs += tp - lastPresent;
    lastPresent = tp;
    St.presents++;
    StatsTick();
    if (!V.tried) V.ok = InitVR();
    if (V.ok && !g_inputPatched) { PatchInput(); g_inputPatched = true; }
    if (!g_gamePatched && Mem<int>(game::GameState) == 9) PatchGameCode();
    if (V.ok) VRFrame(dev);

    HRESULT hr = oPresent(dev, a, b, w, r);
    static int pf = 0;
    if (V.ok && pf < 2) Log("present %d returned %08lX", pf, hr);

    if (V.ok) {
        float hmd[12];
        double tw = NowMs();
        float ctrl[2][12]; int ctrlValid[2] = {0, 0};
        int got = vr_wait_poses(hmd, ctrl, ctrlValid);
        St.waitMs += NowMs() - tw;
        ReadControllers(ctrl, ctrlValid);
        UpdateHandMotion();
        TwoHandTick();
        ThrowTick();
        if (g_inputPatched) BuildInput(!VRActiveInGame());
        if (got) {
            memcpy(V.hmd.m, hmd, sizeof(hmd));
            if (!V.hmdValid) Log("first head pose received");
            V.hmdValid = true;
            if (V.needRecenter) Recenter();
        }
        if (pf < 2) Log("present %d: poses done", pf);
    }
    pf++;
    return hr;
}

static HRESULT STDMETHODCALLTYPE hkReset(IDirect3DDevice9* dev, D3DPRESENT_PARAMETERS* pp) {
    ReleaseD3D9Copies();
    ReleaseHud9();
    ReleaseStereo9();
    HRESULT hr = oReset(dev, pp);
    Log("Device reset (%08lX)", hr);
    return hr;
}

static void HookDevice(IDirect3DDevice9* dev) {
    void** vt = *(void***)dev;
    DWORD old;
    VirtualProtect(&vt[16], sizeof(void*) * 2, PAGE_READWRITE, &old);
    oReset = (Reset_t)vt[16];
    oPresent = (Present_t)vt[17];
    vt[16] = (void*)hkReset;
    vt[17] = (void*)hkPresent;
    VirtualProtect(&vt[16], sizeof(void*) * 2, old, &old);
    Log("Hooked IDirect3DDevice9 Present/Reset");
}

static DWORD WINAPI WaitForDevice(LPVOID) {
    for (int i = 0; i < 6000; i++) {   // up to 10 minutes
        IDirect3DDevice9* dev = Mem<IDirect3DDevice9*>(game::D3DDevicePtr);
        if (dev) { HookDevice(dev); return 0; }
        Sleep(100);
    }
    Log("! Direct3D device never appeared");
    return 0;
}

// Logs the module + offset of crashes so we can find them without a debugger.
static LONG CALLBACK CrashLogger(EXCEPTION_POINTERS* ep) {
    static int count = 0;
    DWORD code = ep->ExceptionRecord->ExceptionCode;
    if (code != EXCEPTION_ACCESS_VIOLATION && code != EXCEPTION_ILLEGAL_INSTRUCTION &&
        code != EXCEPTION_INT_DIVIDE_BY_ZERO && code != EXCEPTION_STACK_OVERFLOW) return EXCEPTION_CONTINUE_SEARCH;
    if (count++ >= 5) return EXCEPTION_CONTINUE_SEARCH;
    void* addr = ep->ExceptionRecord->ExceptionAddress;
    HMODULE mod = nullptr;
    char name[MAX_PATH] = "?";
    if (GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT, (LPCSTR)addr, &mod))
        GetModuleFileNameA(mod, name, MAX_PATH);
    const char* shortName = strrchr(name, '\\') ? strrchr(name, '\\') + 1 : name;
    ULONG_PTR info1 = ep->ExceptionRecord->NumberParameters > 1 ? ep->ExceptionRecord->ExceptionInformation[1] : 0;
    Log("!! EXCEPTION %08lX at %p (%s+0x%lX), data address %08lX, eax=%08lX ecx=%08lX edx=%08lX esp=%08lX",
        code, addr, shortName, (unsigned long)((uintptr_t)addr - (uintptr_t)mod), (unsigned long)info1,
        ep->ContextRecord->Eax, ep->ContextRecord->Ecx, ep->ContextRecord->Edx, ep->ContextRecord->Esp);
    return EXCEPTION_CONTINUE_SEARCH;
}

static bool IsSupportedExe() {
    // 1.0 US: CCamera::Process starts with "sub esp, 0A0h"
    return Mem<uint32_t>(0x52B730) == 0x00A0EC81 && Mem<uint8_t>(0x52C983) == 0xE8;
}

BOOL WINAPI DllMain(HINSTANCE inst, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(inst);
        GetModuleFileNameA(inst, g_dir, MAX_PATH);
        char* slash = strrchr(g_dir, '\\');
        if (slash) slash[1] = 0;
        Log("GTASA_VR stage 8 (build 35) loaded from %s", g_dir);
        if (!IsSupportedExe()) {
            Log("! This gta_sa.exe is not 1.0 US. VR disabled.");
            return TRUE;
        }
        LoadSettings();
        AddVectoredExceptionHandler(0, CrashLogger);
        CreateThread(nullptr, 0, WaitForDevice, nullptr, 0, nullptr);
    } else if (reason == DLL_PROCESS_DETACH) {
        if (g_log) fclose(g_log);
    }
    return TRUE;
}
