#pragma once
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif

/* All 3x4 matrices are OpenVR row-major HmdMatrix34_t (m[row][col] flattened). */
int  vr_init(const char *dll_path, char *err, int errlen);
void vr_shutdown(void);
int  vr_adapter_index(void);
void vr_recommended_size(uint32_t *w, uint32_t *h);
void vr_projection_raw(int eye, float *l, float *r, float *t, float *b);
void vr_eye_to_head(int eye, float out[12]);
int  vr_wait_poses(float hmd[12], float ctrl[2][12], int ctrl_valid[2]);
int  vr_submit(int eye, void *d3d11_tex, float umin, float vmin, float umax, float vmax, const float pose[12]);

int  vr_overlay_create(void);
void vr_overlay_place(const float hmd[12], float distance);
void vr_overlay_show(void *d3d11_tex, int show);

#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
extern "C" {
#endif
int  vr_controller_state(int hand, uint64_t *pressed, uint64_t *touched, float axes[10]);
void vr_haptic(int hand, unsigned short micros);
int  vr_overlay_intersect(const float ctrl[12], float *u, float *v);
#ifdef __cplusplus
}
#endif
#ifdef __cplusplus
extern "C" {
#endif
int  vr_hud_create(float width);
void vr_hud_place(float distance, float down);
void vr_hud_show(void *d3d11_tex, int show);
#ifdef __cplusplus
}
#endif
