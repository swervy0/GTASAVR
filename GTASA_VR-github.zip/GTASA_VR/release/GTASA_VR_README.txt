GTASA_VR - stage 6 (VR view, controllers, motion aiming, hands, manual reload, HUD panel) for GTA San Andreas 1.0 US
====================================================================================

FILES (all go in the game folder, next to gta_sa.exe)
  GTASA_VR.asi      the mod (loaded by your ASI loader)
  openvr_api.dll    Valve's OpenVR runtime library (32-bit)
  GTASA_VR.ini      settings
  GTASA_VR.log      written every launch - send this back if something is wrong

BEFORE YOU PLAY
  1. Start SteamVR first, headset on/awake.
  2. In the game: Options > Display Setup:
       - Frame Limiter: OFF   (otherwise VR is stuck at 25-30 fps)
       - Resolution: 32-bit mode. A taller resolution is sharper in VR (each eye only uses
         the middle part of a 16:9 frame). 1920x1080 works; 2560x1440 is better.
  3. Launch the game. Menus and loading screens appear on a floating screen.
     Once you're in the world, you're in VR.

KEYS (keyboard)
  F8   floating-screen mode on/off (flat game on a big screen, handy for the map)
  F9   recenter (face forward, press it)
  F10  first person / chase camera
  F11  6DOF positional tracking on/off
  F6   calibrate controllers: press F6, then aim both straight ahead until the long buzz (3 s)
       (or hold both thumbstick clicks for 1 s while aiming)
  F7   manual / automatic reloading
  Ctrl+Arrows  move where bullets go for the gun you're HOLDING (1 degree per press).
               Each gun is saved separately ([Gun.Pistol], [Gun.M4], ... in the ini).
  Ctrl+F12  mono mode (same image both eyes; smoother screen recordings)
  PgUp/PgDn         tilt the aim ray
  Numpad 8/2 4/6 7/9  rotate the gun/right hand to match your controller (Shift = left hand)

VR CONTROLLERS (stage 2)
  Menus / map / floating screen
    Point right controller at the screen   moves the game's mouse cursor
    Right trigger                          click
    Right stick up/down                    zoom (map)
    Left stick                             move selection   A = select   B = back
  On foot
    Left stick       walk              Left stick click (hold)   sprint
    Right stick      turn your body    Right stick click         crouch
    Right trigger    fire (aim with your right hand - red dot shows where)
    Left trigger     lock-on only if LeftTriggerLockOn=1
    A                jump / climb      B                         enter vehicle
    X (left A)       action / talk     Grips                     previous / next weapon
  In a vehicle
    Right trigger    accelerate        Left trigger              brake / reverse
    Left stick       steer / lean      A                         handbrake
    B                exit vehicle      Left grip                 fire / nitro
    Right grip (hold)  raise your gun: drive-by aimed with your hand (driver or passenger, cars
                     and bikes). Right trigger shoots; left stick forward/back = gas/brake.
                     Drivers can only drive-by with SMGs (Micro Uzi, Tec-9, MP5) - game rule.
    Right stick click horn             Left stick click          look behind
    X (left A)       next radio station
  Reloading (manual mode)
    Empty gun clicks when you pull the trigger. Bring your left hand to the gun and squeeze
    the left grip to reload (also tops up a half-empty magazine). F7 = manual/automatic.
  Anywhere
    Left menu button (Y/B on left)  tap = pause menu, hold 1 second = recenter view
  Keyboard, mouse and gamepad still work at the same time.

HOW IT WORKS
  The game draws both eyes every frame (FullStereo=1 under [VR]). FullStereo=0 goes back to the
  older, faster-but-choppier mode that draws one eye per frame.
  Your head looks around freely; mouse/gamepad still turns CJ and steers. Your bullets come out of the right
  controller and go where it points (pistols, SMGs, rifles, shotguns, sniper hip-fire).
  Page Up / Page Down tilt the aim if the red dot is off; the value is logged.

HUD
  The HUD, radar, subtitles and help text float on a panel in front of you ([HUD] in the ini).

WHAT IS NOT IN THIS STAGE YET (planned next)
  - motion-controller aiming, hands/guns following your controllers
  - manual reloading (with toggle back to automatic)
  - HUD/radar moved into VR space (right now the radar and corners of the HUD fall outside
    what each eye sees; menus/map are fine on the floating screen)
  - hiding CJ's own head in first person, cutscene comfort options

TROUBLESHOOTING
  Check GTASA_VR.log first.
  - "VR init failed": SteamVR not running, or openvr_api.dll missing.
  - 3D looks wrong / crossed: set SwapEyes=1.
  - Things pop in at the edges of view: raise CullingMargin to 1.3.
  - Seeing the inside of CJ's head: raise HeadForward to 0.15-0.2.
  - Low frame rate: lower the game resolution or draw distance. Turn off ENB/shader mods.

SWING MELEE (build 33)
  On foot, unarmed or holding a melee weapon (knuckles, bat, club, nightstick, knife, katana,
  shovel, cue, cane, chainsaw, dildos/flowers): just swing your real hand into someone.
  Left hand always punches as a fist; right hand uses whatever melee weapon you hold, with its
  real reach (bat/katana hit from the end, knife is short). Faster swing = more damage,
  head hits do 1.5x. Controller buzzes on a hit. The trigger still does the normal game attack.
  Optional ini keys under [Controls]:
    SwingMelee=1      0 turns it off
    SwingSpeed=2.2    how fast (m/s) you must swing for a hit; raise if light moves hit people
    MeleeDamage=1.0   damage multiplier

BUILD 35 - NEW
  THROWING  Hold a grenade/molotov/tear gas/satchel, hold the right trigger, make a real throw and
            let go of the trigger at the end of the swing. It flies from your hand with your hand's
            speed and direction. Rockets (RPG / heat-seeker) now launch out of the launcher along it.
            [Controls] ThrowByHand=1, ThrowStrength=1.6 (raise if throws feel weak)
  TWO HANDS Long guns (shotguns, MP5, AK, M4, rifles, sniper, RPG, flamer, minigun): put your left
            hand out in front of your right hand and squeeze the left grip. The gun now aims along
            the line from your right hand to your left hand. Let go of the left grip to release.
            (Reloading is still: left hand right at the gun + left grip.)   [Controls] TwoHanded=1
  SCOPE     Sniper rifle / camera: bring it up to your eye and the view zooms in. Right stick up/down
            changes the zoom. Move it away from your face to zoom out.     [Controls] ScopeZoom=4
  RECOIL    Every shot buzzes the controller (both hands when holding two-handed). RecoilHaptics=1
  CROUCH    Crouch down for real and CJ crouches; stand up and he stands. Your view and hands stay
            matched to his body. (Right stick click still toggles crouch too.)
            [Controls] RealCrouch=1, CrouchDepth=0.35 (metres your head must drop)
            Long-press the left menu button (recenter) while STANDING so it learns your height.
  HOLSTERS  Grab (right grip) at a spot on your body to pick a weapon:
              over right shoulder = assault rifles / shotguns   over left shoulder = rifles / heavy
              right hip = pistols        left hip = melee / spray can / camera
              middle of chest = SMGs     left side of chest = grenades & co / gifts / detonator
            Grab again to cycle that spot; grab the spot of the gun you hold to put it away.
            Right grip anywhere else still cycles to the next weapon.      [Controls] Holsters=1
  SWIMMING  Do breaststrokes (pull both hands back) to swim forward; hard strokes swim faster.
            The stick still works too.                                     [Controls] SwimStrokes=1
  WHEEL     In cars/boats hold BOTH grips = hands on the wheel: turn it like a real wheel.
            On bikes/quads: push one hand forward and pull the other back (handlebars).
            Release the LEFT grip (keep the right) = gun up for a drive-by, as before.
            Nitro / car weapon moved to the LEFT STICK CLICK (grips now hold the wheel).
            [Controls] WheelSteering=1, WheelMaxAngle=90 (degrees of turn for full lock)
  SPEED     Finished frames are now handed to SteamVR at the start of the next frame instead of
            making the game wait for the graphics card. [VR] PipelinedSubmit=1 (0 = old way)
  SHARPNESS The image per eye comes from the game's resolution. For a much sharper picture turn on
            NVIDIA DSR (or AMD Virtual Super Resolution) in the driver, then pick a bigger mode in
            the game's Display Setup - a taller 4:3 one like 2880x2160 works best for VR.
