#!/bin/sh
set -e
cd "$(dirname "$0")"
OVR=third_party/openvr/headers
mkdir -p build out
i686-w64-mingw32-gcc -O2 -std=c11 -I$OVR -c src/vrapi.c -o build/vrapi.o
i686-w64-mingw32-g++ -O2 -std=c++17 -Wall -Wno-unknown-pragmas -I$OVR -c src/main.cpp -o build/main.o
i686-w64-mingw32-g++ -shared -o out/GTASA_VR.asi build/main.o build/vrapi.o \
  -static -static-libgcc -static-libstdc++ -Wl,--enable-stdcall-fixup -s -luuid
echo built
