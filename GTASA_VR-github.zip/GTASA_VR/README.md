# GTASA_VR — full VR for classic GTA San Andreas

A SteamVR mod for the **classic PC version of GTA San Andreas (v1.0 US)**: 6DOF head tracking, full
stereo rendering, and full motion controls. It plays the original game in first person with your
real hands.

> Not for the Definitive Edition. Doesn't work on unpatched Steam/Rockstar Launcher versions
> until they are downgraded to 1.0 (see below).

## Features

- **6DOF head tracking**, true stereo, both eyes rendered every frame (lights, reflections, shadows
  and mission markers correct in both eyes). Mono mode (Ctrl+F12) for recording.
- **Hands follow your controllers**: CJ's arms are IK-driven, the gun sits in your hand.
- **Motion aiming**: bullets leave the barrel and go where the gun points; red dot + laser.
  Per-gun fine-tuning saved per weapon.
- **Two-handed long guns**: grab the front of the gun with your left hand.
- **Manual reloading** (left hand to the gun + grip), or switch to automatic.
- **Melee by swinging** your fists or weapon into people.
- **Throwing by hand**: grenades and molotovs leave your hand at your throw's speed and direction. Rockets fire from the launcher.
- **Scopes**: bring the sniper rifle / camera to your eye to zoom.
- **Holsters**: grab over your shoulders, at your hips or chest to pick weapons.
- **Real crouching**, **swimming with arm strokes**, **recoil haptics**.
- **Steering wheel / handlebars** with both hands, and **hand-aimed drive-bys** from the driver or
  passenger seat (cars and bikes).
- **Smooth turning or snap turning**, the body follows your head, strafing.
- **HUD, radar and subtitles** on a floating panel. Menus use a virtual screen you point at with the
  controllers.

Full controls: [`release/GTASA_VR_README.txt`](release/GTASA_VR_README.txt).
Every option: [`release/GTASA_VR.ini`](release/GTASA_VR.ini).

## Requirements

| What | Needed? | Where |
|---|---|---|
| GTA San Andreas (classic PC), **v1.0 US** `gta_sa.exe` (14,383,616 bytes) | **Required** | Your own copy. Steam/Rockstar Launcher copies: downgrade with [Jetpack Downgrader](https://github.com/Zalexanninev15/Jetpack-Downgrader) |
| An ASI loader | **Required** | [Silent's ASI Loader](https://cookieplmonster.github.io/mods/gta-sa/#asiloader) or [Ultimate ASI Loader](https://github.com/ThirteenAG/Ultimate-ASI-Loader) |
| SteamVR + a PC VR headset | **Required** | Steam |
| OpenVR runtime DLL (`openvr_api.dll`) | **Required** | Included in `release/` |
| [SilentPatch](https://github.com/CookiePLMonster/SilentPatch) | Recommended | GitHub releases |
| CLEO, [GInput](https://cookieplmonster.github.io/mods/gta-sa/#ginput), [Mod Loader](https://github.com/thelink2012/modloader), Limit Adjuster | Optional (tested alongside) | Their own pages |
| Widescreen Fix | **Don't use** | It fights the VR camera |

## Install

1. Downgrade the game to 1.0 if needed and install an ASI loader (and SilentPatch).
2. Copy everything in **`release/`** into your game folder (next to `gta_sa.exe`).
3. Start SteamVR, then start the game.
4. In game: hold the **left menu button** to recenter while standing. Press **F6** and hold both
   controllers like you're aiming a gun straight ahead to calibrate your grip.

`GTASA_VR.log` in the game folder shows what's happening. Attach it to bug reports.

## Building from source

Cross-compiled with MinGW-w64 (32-bit), no Visual Studio needed:

```sh
sudo apt install g++-mingw-w64-i686   # Debian/Ubuntu/WSL
./build.sh                            # -> out/GTASA_VR.asi
```

- `src/main.cpp`: the whole mod (hooks, camera, stereo, input, IK, weapons).
- `src/vrapi.c/.h`: a small C bridge to OpenVR's flat C API (`openvr_api.dll` is loaded at runtime).
- `third_party/openvr/headers`: OpenVR SDK headers (BSD-3-Clause, see its LICENSE).

Game addresses are for the 1.0 US executable only.

## Credits

- Valve: [OpenVR](https://github.com/ValveSoftware/openvr) (BSD-3-Clause).
- The GTA reverse-engineering community: [gta-reversed](https://github.com/gta-reversed/gta-reversed-modern)
  and [plugin-sdk](https://github.com/DK22Pac/plugin-sdk), used as references for game structures and addresses.
- Silent (CookiePLMonster) for SilentPatch, GInput and the ASI loader.

GTA San Andreas is © Rockstar Games. This project contains no game files and is not affiliated
with or endorsed by Rockstar Games or Take-Two Interactive.
